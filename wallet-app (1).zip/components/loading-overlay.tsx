interface LoadingOverlayProps {
  text: string
}

export function LoadingOverlay({ text }: LoadingOverlayProps) {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-purple-900/80 via-pink-900/80 to-purple-900/80 backdrop-blur-sm z-[9999] flex items-center justify-center">
      <div className="text-center bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-purple-500/30 shadow-2xl">
        <div className="w-16 h-16 border-4 border-purple-300/20 border-t-purple-400 rounded-full animate-spin mx-auto mb-6"></div>
        <p className="text-white font-bold text-lg text-shadow-sm bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text text-transparent">
          {text}
        </p>
      </div>
    </div>
  )
}
