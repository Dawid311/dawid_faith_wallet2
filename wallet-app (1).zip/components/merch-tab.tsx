"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Modal } from "@/components/modal"

interface MerchTabProps {
  setIsLoading: (loading: boolean) => void
  setLoadingText: (text: string) => void
}

interface MerchItem {
  id: string
  typ: string
  titel: string
  beschreibung: string
  bildUrl: string
  mediaUrl?: string
  posterUrl?: string
  preis: string
}

export function MerchTab({ setIsLoading, setLoadingText }: MerchTabProps) {
  const [merchItems, setMerchItems] = useState<MerchItem[]>([])
  const [selectedItem, setSelectedItem] = useState<MerchItem | null>(null)
  const [showPurchaseModal, setShowPurchaseModal] = useState(false)
  const [purchaseForm, setPurchaseForm] = useState({
    email: "",
    name: "",
    straße: "",
    plz: "",
    ort: "",
    land: "",
  })

  useEffect(() => {
    loadMerchItems()
  }, [])

  const loadMerchItems = async () => {
    setIsLoading(true)
    setLoadingText("Lade Produkte...")

    try {
      // Mock merch data - replace with actual API call
      const mockItems: MerchItem[] = [
        {
          id: "1",
          typ: "audio",
          titel: "Exclusive Track #1",
          beschreibung: "Unreleased song from the vault",
          bildUrl: "/placeholder.svg?height=200&width=200",
          mediaUrl: "/placeholder.mp3",
          preis: "15",
        },
        {
          id: "2",
          typ: "video",
          titel: "Behind the Scenes",
          beschreibung: "Exclusive behind the scenes footage",
          bildUrl: "/placeholder.svg?height=200&width=200",
          mediaUrl: "/placeholder.mp4",
          posterUrl: "/placeholder.svg?height=200&width=200",
          preis: "25",
        },
        {
          id: "3",
          typ: "merch",
          titel: "Limited Edition T-Shirt",
          beschreibung: "Premium quality cotton t-shirt",
          bildUrl: "/placeholder.svg?height=200&width=200",
          preis: "50",
        },
      ]

      setTimeout(() => {
        setMerchItems(mockItems)
        setIsLoading(false)
      }, 1000)
    } catch (error) {
      console.error("Error loading merch:", error)
      setIsLoading(false)
    }
  }

  const handlePurchase = (item: MerchItem) => {
    setSelectedItem(item)
    setShowPurchaseModal(true)
  }

  const submitPurchase = async () => {
    if (!purchaseForm.email) {
      alert("⚠️ Bitte gib deine E-Mail-Adresse ein!")
      return
    }

    setIsLoading(true)
    setLoadingText("Zahlung wird verarbeitet...")

    try {
      // Simulate purchase transaction
      setTimeout(() => {
        alert("✅ Zahlung erfolgreich! Bitte check deine E-Mails.")
        setShowPurchaseModal(false)
        setPurchaseForm({
          email: "",
          name: "",
          straße: "",
          plz: "",
          ort: "",
          land: "",
        })
        setIsLoading(false)
      }, 2000)
    } catch (error) {
      alert("❌ Fehler bei der Transaktion")
      setIsLoading(false)
    }
  }

  return (
    <div className="container mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 justify-items-center">
        {merchItems.map((item) => (
          <Card key={item.id} className="w-full max-w-sm bg-white text-black shadow-lg">
            <CardContent className="p-6 text-center">
              <img
                src={item.bildUrl || "/placeholder.svg"}
                alt={item.titel}
                className="w-full h-48 object-cover rounded-lg mb-4"
              />

              <h3 className="text-xl font-bold mb-2">{item.titel}</h3>
              <p className="text-gray-600 mb-4">{item.beschreibung}</p>

              {/* Media Preview */}
              {item.typ === "audio" && item.mediaUrl && (
                <audio controls className="w-full mb-4">
                  <source src={item.mediaUrl} type="audio/mpeg" />
                </audio>
              )}

              {item.typ === "video" && item.mediaUrl && (
                <video controls className="w-full mb-4 rounded-lg" poster={item.posterUrl}>
                  <source src={item.mediaUrl} type="video/mp4" />
                </video>
              )}

              <div className="text-lg font-bold mb-4">🎧 {item.preis} D.Faith</div>

              <Button
                onClick={() => handlePurchase(item)}
                className="w-full bg-pink-500 hover:bg-pink-600 text-white font-bold py-2 px-4 rounded-full"
              >
                Jetzt kaufen
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Purchase Modal */}
      <Modal isOpen={showPurchaseModal} onClose={() => setShowPurchaseModal(false)}>
        {selectedItem && (
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-2 text-black">{selectedItem.titel}</h2>
            <p className="text-gray-600 mb-4">{selectedItem.beschreibung}</p>
            <div className="text-xl font-bold mb-6 text-black">🎧 {selectedItem.preis} D.Faith</div>

            <div className="space-y-4">
              <Input
                type="email"
                placeholder="E-Mail-Adresse (Pflicht)"
                value={purchaseForm.email}
                onChange={(e) => setPurchaseForm({ ...purchaseForm, email: e.target.value })}
                required
              />
              <Input
                placeholder="Name (optional)"
                value={purchaseForm.name}
                onChange={(e) => setPurchaseForm({ ...purchaseForm, name: e.target.value })}
              />
              <Input
                placeholder="Straße (optional)"
                value={purchaseForm.straße}
                onChange={(e) => setPurchaseForm({ ...purchaseForm, straße: e.target.value })}
              />
              <Input
                placeholder="Postleitzahl (optional)"
                value={purchaseForm.plz}
                onChange={(e) => setPurchaseForm({ ...purchaseForm, plz: e.target.value })}
              />
              <Input
                placeholder="Ort (optional)"
                value={purchaseForm.ort}
                onChange={(e) => setPurchaseForm({ ...purchaseForm, ort: e.target.value })}
              />
              <Input
                placeholder="Land (optional)"
                value={purchaseForm.land}
                onChange={(e) => setPurchaseForm({ ...purchaseForm, land: e.target.value })}
              />
            </div>

            <div className="flex gap-4 mt-6">
              <Button
                onClick={submitPurchase}
                className="flex-1 bg-pink-500 hover:bg-pink-600 text-white font-bold py-3 rounded-full"
              >
                Jetzt kaufen
              </Button>
              <Button
                onClick={() => setShowPurchaseModal(false)}
                className="flex-1 bg-red-500 hover:bg-red-600 text-white font-bold py-3 rounded-full"
              >
                ✕
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
