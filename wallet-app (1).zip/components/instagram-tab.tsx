"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Modal } from "@/components/modal"

interface InstagramTabProps {
  setIsLoading: (loading: boolean) => void
  setLoadingText: (text: string) => void
}

interface UserData {
  username: string
  image: string
  expTotal: number
  expInstagram: number
  expTiktok: number
  expStream: number
  expFacebook: number
  liveNFTBonus: number
  miningpower: number
  liked: string
  commented: string
  story: string
  saved: string
}

export function InstagramTab({ setIsLoading, setLoadingText }: InstagramTabProps) {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [showUpgradeModal, setShowUpgradeModal] = useState(false)
  const [showClaimModal, setShowClaimModal] = useState(false)
  const [showInfoModal, setShowInfoModal] = useState(false)
  const [walletAddress, setWalletAddress] = useState("")
  const [claimStatus, setClaimStatus] = useState("")

  useEffect(() => {
    loadUserData()
  }, [])

  const loadUserData = async () => {
    setIsLoading(true)
    setLoadingText("⏳ Wird verarbeitet...")

    try {
      // Simulate API call - replace with actual endpoint
      const mockData: UserData = {
        username: "User",
        image: "/placeholder.svg?height=100&width=100",
        expTotal: 150,
        expInstagram: 50,
        expTiktok: 30,
        expStream: 40,
        expFacebook: 20,
        liveNFTBonus: 10,
        miningpower: 25,
        liked: "true",
        commented: "false",
        story: "true",
        saved: "false",
      }

      setTimeout(() => {
        setUserData(mockData)
        setIsLoading(false)
      }, 1500)
    } catch (error) {
      console.error("Error loading user data:", error)
      setIsLoading(false)
    }
  }

  const getLevelInfo = (exp: number) => {
    const levelThresholds = [39, 119, 239, 399, 599, 839, 1119, 1439, 1799, 2199]
    const levelMins = [0, 40, 120, 240, 400, 600, 840, 1120, 1440, 1800]

    for (let i = 0; i < levelThresholds.length; i++) {
      if (exp <= levelThresholds[i]) {
        return {
          level: i + 1,
          minExp: levelMins[i],
          maxExp: levelThresholds[i],
          currentExp: exp - levelMins[i],
          range: levelThresholds[i] - levelMins[i],
        }
      }
    }
    return { level: 50, minExp: 0, maxExp: 100, currentExp: 0, range: 100 }
  }

  const submitClaim = async () => {
    if (!walletAddress.startsWith("0x") || walletAddress.length < 42) {
      setClaimStatus("❌ Ungültige Wallet-Adresse.")
      return
    }

    setIsLoading(true)
    setLoadingText("⏳ Claim wird verarbeitet...")

    try {
      // Simulate claim submission
      setTimeout(() => {
        setClaimStatus("✅ Claim erfolgreich ausgelöst!")
        setIsLoading(false)
      }, 2000)
    } catch (error) {
      setClaimStatus("❌ Fehler beim Claim.")
      setIsLoading(false)
    }
  }

  if (!userData) return null

  const levelInfo = getLevelInfo(userData.expTotal)
  const progressPercent = Math.round((levelInfo.currentExp / levelInfo.range) * 100)

  return (
    <div className="flex justify-center">
      <Card className="w-full max-w-2xl bg-pink-500/20 border-2 border-white/15 backdrop-blur-sm">
        <CardContent className="p-8 text-center">
          <div className="text-2xl font-bold mb-4">@{userData.username}</div>

          <img
            src={userData.image || "/placeholder.svg"}
            alt="Profile"
            className="w-24 h-24 rounded-full mx-auto mb-6 object-cover"
          />

          {/* Level Box */}
          <div className="bg-black/20 rounded-3xl p-6 mb-6">
            <div className="flex justify-between items-center mb-4">
              <div className="text-xl font-bold">Level {levelInfo.level}</div>
              <div className="text-lg">
                {userData.expTotal} / {levelInfo.maxExp} EXP
              </div>
              <Button
                onClick={() => setShowInfoModal(true)}
                className="w-7 h-7 rounded-full bg-white text-pink-500 font-bold text-sm p-0"
              >
                i
              </Button>
            </div>

            <div className="relative bg-gray-800 rounded-full h-4 overflow-hidden mb-4">
              <div
                className="h-full bg-gradient-to-r from-orange-400 via-pink-500 to-purple-600 transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
              <div className="absolute inset-0 flex items-center justify-center text-white text-xs font-bold">
                {progressPercent}%
              </div>
            </div>

            <div className="text-yellow-300 text-lg">⛏ +{userData.miningpower} D.Faith</div>
          </div>

          {/* System Check */}
          <div className="border-2 border-white rounded-3xl p-6 mb-6 bg-white/5">
            <div className="font-bold text-xl mb-4">✅ System Check</div>
            <div className="space-y-3 text-left">
              <div className="flex justify-between">
                <span>❤️ Like</span>
                <span>{userData.liked === "true" ? "✅" : "❌"} +10 EXP</span>
              </div>
              <div className="flex justify-between">
                <span>💬 Kommentar</span>
                <span>{userData.commented === "true" ? "✅" : "❌"} +10 EXP</span>
              </div>
              <div className="flex justify-between">
                <span>📣 Story</span>
                <span>{userData.story === "true" ? "✅" : "❌"} +20 EXP</span>
              </div>
              <div className="flex justify-between">
                <span>💾 Save</span>
                <span>{userData.saved === "true" ? "✅" : "❌"} +10 EXP</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 justify-center">
            <Button
              onClick={() => setShowUpgradeModal(true)}
              className="bg-gradient-to-r from-orange-400 to-pink-500 hover:from-orange-500 hover:to-pink-600 text-white font-bold px-8 py-3 rounded-full text-lg shadow-lg transform hover:scale-105 transition-all"
            >
              ✨ Upgrade
            </Button>
            <Button
              onClick={() => setShowClaimModal(true)}
              className="bg-gradient-to-r from-orange-400 to-pink-500 hover:from-orange-500 hover:to-pink-600 text-white font-bold px-8 py-3 rounded-full text-lg shadow-lg transform hover:scale-105 transition-all"
            >
              🪙 Claim
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Modals */}
      <Modal isOpen={showUpgradeModal} onClose={() => setShowUpgradeModal(false)}>
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4 text-black">✨ Upgrade deine EXP!</h2>
          <div className="space-y-4">
            <Button className="w-full bg-gradient-to-r from-orange-400 to-pink-500 text-white">❤️ 💾 Like + Save</Button>
            <Button className="w-full bg-gradient-to-r from-orange-400 to-pink-500 text-white">📣 Story teilen</Button>
          </div>
          <Button onClick={() => setShowUpgradeModal(false)} className="mt-4 bg-red-500 hover:bg-red-600 text-white">
            ❌ Schließen
          </Button>
        </div>
      </Modal>

      <Modal isOpen={showClaimModal} onClose={() => setShowClaimModal(false)}>
        <div className="text-center">
          <h2 className="text-xl font-bold mb-4 text-black">🪙 Claim</h2>
          <p className="mb-4 text-black">Gib deine Wallet-Adresse ein, um deinen Claim auszulösen:</p>
          <input
            type="text"
            value={walletAddress}
            onChange={(e) => setWalletAddress(e.target.value)}
            placeholder="0x..."
            className="w-full p-3 border rounded-lg mb-4 text-black"
          />
          <Button onClick={submitClaim} className="w-full bg-green-500 hover:bg-green-600 text-white mb-4">
            ✅ Claim absenden
          </Button>
          {claimStatus && (
            <p className={`mb-4 ${claimStatus.includes("✅") ? "text-green-600" : "text-red-600"}`}>{claimStatus}</p>
          )}
          <Button onClick={() => setShowClaimModal(false)} className="bg-red-500 hover:bg-red-600 text-white">
            ❌ Schließen
          </Button>
        </div>
      </Modal>

      <Modal isOpen={showInfoModal} onClose={() => setShowInfoModal(false)}>
        <div className="text-center">
          <h2 className="text-xl font-bold mb-4 text-black">📊 Deine EXP-Quellen</h2>
          <div className="text-left space-y-3 text-black">
            <div className="flex justify-between border-l-4 border-pink-500 pl-3">
              <span>📱 Instagram:</span>
              <span>{userData.expInstagram} EXP</span>
            </div>
            <div className="flex justify-between border-l-4 border-black pl-3">
              <span>🎵 TikTok:</span>
              <span>{userData.expTiktok} EXP</span>
            </div>
            <div className="flex justify-between border-l-4 border-blue-500 pl-3">
              <span>📘 Facebook:</span>
              <span>{userData.expFacebook} EXP</span>
            </div>
            <div className="flex justify-between border-l-4 border-purple-500 pl-3">
              <span>🎥 Stream:</span>
              <span>{userData.expStream} EXP</span>
            </div>
            <div className="flex justify-between border-l-4 border-yellow-500 pl-3">
              <span>⭐ Live Bonus:</span>
              <span>+{userData.liveNFTBonus}%</span>
            </div>
          </div>
          <Button onClick={() => setShowInfoModal(false)} className="mt-6 bg-red-500 hover:bg-red-600 text-white">
            ❌ Schließen
          </Button>
        </div>
      </Modal>
    </div>
  )
}
