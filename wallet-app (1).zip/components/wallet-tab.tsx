"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Modal } from "@/components/modal"

interface WalletTabProps {
  setIsLoading: (loading: boolean) => void
  setLoadingText: (text: string) => void
}

export function WalletTab({ setIsLoading, setLoadingText }: WalletTabProps) {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [email, setEmail] = useState("")
  const [walletAddress, setWalletAddress] = useState("")
  const [dfaithBalance, setDfaithBalance] = useState("0.00")
  const [maticBalance, setMaticBalance] = useState("0.00")
  const [showBuyModal, setShowBuyModal] = useState(false)
  const [showSellModal, setShowSellModal] = useState(false)
  const [showSendModal, setShowSendModal] = useState(false)

  const loginWithEmail = async () => {
    if (!email || !email.includes("@")) {
      alert("Bitte gib eine gültige E-Mail-Adresse ein.")
      return
    }

    setIsLoading(true)
    setLoadingText("🔐 Wallet wird erstellt...")

    try {
      // Simulate Magic SDK login
      setTimeout(() => {
        const mockAddress = "0x1234567890123456789012345678901234567890"
        setWalletAddress(mockAddress)
        setDfaithBalance("125.50")
        setMaticBalance("2.45")
        setIsLoggedIn(true)
        setIsLoading(false)
      }, 2000)
    } catch (error) {
      console.error("Login failed:", error)
      setIsLoading(false)
    }
  }

  const copyWalletAddress = () => {
    navigator.clipboard.writeText(walletAddress)
    alert("✅ Adresse wurde kopiert!")
  }

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`
  }

  if (!isLoggedIn) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Card className="w-full max-w-md bg-white/10 backdrop-blur-sm border-white/20">
          <CardContent className="p-8 text-center">
            <p className="text-yellow-300 mb-6 text-lg">
              🔐 Durch die Eingabe deiner E-Mail-Adresse wird automatisch eine Wallet erstellt.
            </p>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              className="mb-4 text-center bg-white text-black"
            />
            <Button
              onClick={loginWithEmail}
              className="w-full bg-gradient-to-r from-orange-400 to-pink-500 hover:from-orange-500 hover:to-pink-600 text-white font-bold py-3 rounded-full"
            >
              🔐 Login
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="flex justify-center">
      <Card className="w-full max-w-2xl bg-white text-black shadow-2xl">
        <CardContent className="p-8">
          {/* MATIC Badge */}
          <div className="absolute top-4 left-4 bg-gray-100 rounded-2xl px-3 py-2 text-sm font-bold text-purple-600 flex items-center gap-2">
            <span>⬡</span>
            <span>{maticBalance} MATIC</span>
          </div>

          <h2 className="text-2xl font-bold text-center mb-6 bg-gradient-to-r from-orange-400 via-pink-500 to-purple-600 bg-clip-text text-transparent">
            💼 Wallet
          </h2>

          {/* Wallet Address */}
          <div className="flex justify-between items-center bg-gray-100 rounded-xl p-4 mb-6">
            <span className="font-mono text-sm flex-1 truncate">{formatAddress(walletAddress)}</span>
            <Button
              onClick={copyWalletAddress}
              className="ml-3 bg-gradient-to-r from-orange-400 to-pink-500 text-white px-4 py-2 rounded-full text-sm"
            >
              Kopieren
            </Button>
          </div>

          {/* Balance */}
          <div className="text-center mb-8">
            <div className="text-3xl font-bold text-orange-500 mb-2">{dfaithBalance} D.Faith</div>
            <div className="text-orange-400">≈ {(Number.parseFloat(dfaithBalance) * 0.5).toFixed(2)} € Gesamtwert</div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-4">
            <Button
              onClick={() => setShowBuyModal(true)}
              className="w-full bg-gradient-to-r from-orange-400 to-orange-600 hover:from-orange-500 hover:to-orange-700 text-white font-bold py-3 rounded-full"
            >
              🛒 Kaufen
            </Button>
            <Button
              onClick={() => setShowSellModal(true)}
              className="w-full bg-gradient-to-r from-red-400 to-red-600 hover:from-red-500 hover:to-red-700 text-white font-bold py-3 rounded-full"
            >
              💲 Verkaufen
            </Button>
            <Button
              onClick={() => setShowSendModal(true)}
              className="w-full bg-gradient-to-r from-purple-400 to-purple-600 hover:from-purple-500 hover:to-purple-700 text-white font-bold py-3 rounded-full"
            >
              ➡️ Senden
            </Button>
            <Button className="w-full bg-gradient-to-r from-orange-400 to-pink-500 hover:from-orange-500 hover:to-pink-600 text-white font-bold py-3 rounded-full">
              📜 Historie
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Buy Modal */}
      <Modal isOpen={showBuyModal} onClose={() => setShowBuyModal(false)}>
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4 text-black">🛒 D.Faith kaufen</h2>
          <p className="text-gray-600 mb-6">Aktueller Preis: ≈ 0,50 € pro D.Faith</p>
          <div className="space-y-4">
            <Button className="w-full bg-gradient-to-r from-orange-400 to-pink-500 text-white py-3">
              🛍️ Fan – 10 bis 999 Tokens
            </Button>
            <Button className="w-full bg-gradient-to-r from-orange-400 to-pink-500 text-white py-3">
              💎 Investor – 1000+ Tokens
            </Button>
            <Button className="w-full bg-gradient-to-r from-purple-400 to-purple-600 text-white py-3">
              💢 Mit MATIC kaufen
            </Button>
          </div>
          <Button onClick={() => setShowBuyModal(false)} className="mt-6 bg-red-500 hover:bg-red-600 text-white">
            Schließen
          </Button>
        </div>
      </Modal>

      {/* Sell Modal */}
      <Modal isOpen={showSellModal} onClose={() => setShowSellModal(false)}>
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4 text-black">💱 D.Faith verkaufen</h2>
          <p className="text-gray-600 mb-6">Tausche deine D.Faith Tokens gegen MATIC</p>
          <Input type="number" placeholder="z.B. 10 D.Faith" className="mb-4 text-center" />
          <div className="space-y-3">
            <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white">🔄 Quote laden</Button>
            <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white">🔓 D.Faith freigeben</Button>
            <Button className="w-full bg-green-500 hover:bg-green-600 text-white">
              ✅ Tausche D.Faith gegen MATIC
            </Button>
          </div>
          <div className="bg-gray-100 rounded-lg p-4 mt-4">
            <p className="text-black">
              <strong>Wechselkurs:</strong> <span>…</span>
            </p>
          </div>
          <Button onClick={() => setShowSellModal(false)} className="mt-6 bg-red-500 hover:bg-red-600 text-white">
            ❌ Schließen
          </Button>
        </div>
      </Modal>

      {/* Send Modal */}
      <Modal isOpen={showSendModal} onClose={() => setShowSendModal(false)}>
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4 text-black">D.Faith/MATIC senden</h2>
          <select className="w-full p-3 border rounded-lg mb-4 text-center">
            <option value="dfaith">D.Faith</option>
            <option value="matic">MATIC</option>
          </select>
          <div className="text-orange-500 font-bold mb-4">Balance: {dfaithBalance} D.Faith</div>
          <Input placeholder="Empfänger-Adresse (0x...)" className="mb-4" />
          <div className="relative mb-4">
            <Input type="number" placeholder="Anzahl z.B. 5" className="pr-16" />
            <Button className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-orange-400 text-white px-3 py-1 text-sm rounded">
              Max
            </Button>
          </div>
          <Button className="w-full bg-purple-500 hover:bg-purple-600 text-white mb-4">✅ Senden</Button>
          <Button onClick={() => setShowSendModal(false)} className="bg-red-500 hover:bg-red-600 text-white">
            Schließen
          </Button>
        </div>
      </Modal>
    </div>
  )
}
