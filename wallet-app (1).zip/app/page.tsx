"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Modal } from "@/components/modal"
import { LoadingOverlay } from "@/components/loading-overlay"

// D.Faith token contract details
const DFAITH_CONTRACT_ADDRESS = "0xEE27258975a2DA946CD5025134D70E5E24F6789F"
const WPOL_CONTRACT_ADDRESS = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270" // WPOL (Wrapped POL)
const NATIVE_POL_ADDRESS = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE" // Native POL placeholder
const DFAITH_DECIMALS = 18
const POLYGONSCAN_API_KEY = "V6Q5223DMWPP3HQJE9IJ8UIHSP3NUHID5K"
const WMATIC_CONTRACT_ADDRESS = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

const DINVEST_CONTRACT_ADDRESS = "0xa3f0Bf2a9d7f1a0958989Ea4c4DBE8B595117643"
const DINVEST_DECIMALS = 0

const STAKING_CONTRACT_ADDRESS = "0x14d9889892849a1D161c9272a07Fa16Fef79f1AE"

// ParaSwap TokenTransferProxy address
const PARASWAP_TOKEN_TRANSFER_PROXY = "0x216b4b4ba9f3e719726886d34a177484278bfcae"

const ERC20_ABI = [
  "function balanceOf(address owner) view returns (uint256)",
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function transfer(address to, uint256 amount) returns (bool)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function approve(address spender, uint256 amount) returns (bool)",
]

export default function WalletApp() {
  // Navigation state
  const [activeTab, setActiveTab] = useState("wallet")
  const [showSocialDropdown, setShowSocialDropdown] = useState(false)
  const [showMobileMenu, setShowMobileMenu] = useState(false)

  const [isLoading, setIsLoading] = useState(false)
  const [loadingText, setLoadingText] = useState("Wird verarbeitet...")
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [email, setEmail] = useState("")
  const [walletAddress, setWalletAddress] = useState("")
  const [dfaithBalance, setDfaithBalance] = useState("0.00")
  const [maticBalance, setMaticBalance] = useState("0.00")
  const [dinvestBalance, setDinvestBalance] = useState("0")

  const [stakedDinvestAmount, setStakedDinvestAmount] = useState("0")
  const [earnedDfaithRewards, setEarnedDfaithRewards] = useState("0.00")
  const [stakeAmount, setStakeAmount] = useState("")
  const [unstakeAmount, setUnstakeAmount] = useState("")

  const [magic, setMagic] = useState<any>(null)
  const [web3, setWeb3] = useState<any>(null)
  const [sdkReady, setSdkReady] = useState(false)

  // Price data
  const [dfaithPriceUSD, setDfaithPriceUSD] = useState("0.50")

  // Modal states
  const [showBuyModal, setShowBuyModal] = useState(false)
  const [showSellModal, setShowSellModal] = useState(false)
  const [showSendModal, setShowSendModal] = useState(false)
  const [showHistoryModal, setShowHistoryModal] = useState(false)
  const [showMaticBuyModal, setShowMaticBuyModal] = useState(false)

  const [showStakingModal, setShowStakingModal] = useState(false)
  const [showDinvestInfoModal, setShowDinvestInfoModal] = useState(false)

  // Sell modal states
  const [sellAmount, setSellAmount] = useState("")
  const [sellQuote, setSellQuote] = useState<any>(null)
  const [isApproved, setIsApproved] = useState(false)

  // Buy with MATIC modal states
  const [buyAmount, setBuyAmount] = useState("")
  const [buyQuote, setBuyQuote] = useState<any>(null)
  const [isMaticApproved, setIsMaticApproved] = useState(false)

  // Send modal states
  const [sendToken, setSendToken] = useState("dfaith")
  const [sendAmount, setSendAmount] = useState("")
  const [sendAddress, setSendAddress] = useState("")

  // Transaction history state
  const [transactions, setTransactions] = useState<any[]>([])

  // Auto-refresh state
  const [refreshInterval, setRefreshInterval] = useState<NodeJS.Timeout | null>(null)

  // Rewards display state
  const [showFullRewards, setShowFullRewards] = useState(false)

  const [dinvestBuyClicked, setDinvestBuyClicked] = useState(false)

  // Initialize Magic SDK on component mount
  useEffect(() => {
    initializeMagic()
    loadPriceData()
  }, [])

  // Auto-refresh mechanism - 5 seconds
  useEffect(() => {
    if (isLoggedIn && web3 && walletAddress) {
      // Start auto-refresh
      const interval = setInterval(async () => {
        console.log("🔄 Auto-refresh: Aktualisiere Daten...")
        try {
          await loadBalances(walletAddress, web3)
          await loadPriceData()
        } catch (error) {
          console.error("❌ Auto-refresh Fehler:", error)
        }
      }, 5000) // 5 seconds

      setRefreshInterval(interval)

      // Cleanup on unmount or logout
      return () => {
        if (interval) {
          clearInterval(interval)
        }
      }
    } else {
      // Clear interval if not logged in
      if (refreshInterval) {
        clearInterval(refreshInterval)
        setRefreshInterval(null)
      }
    }
  }, [isLoggedIn, web3, walletAddress])

  // Load real price data from ParaSwap
  const loadPriceData = async () => {
    try {
      console.log("💰 Lade echte DFAITH Preisdaten von ParaSwap...")

      // Get D.Faith price using ParaSwap - 1 MATIC to D.Faith
      const priceUrl = `https://apiv5.paraswap.io/prices?srcToken=${WMATIC_CONTRACT_ADDRESS}&destToken=${DFAITH_CONTRACT_ADDRESS}&amount=1000000000000000000&srcDecimals=18&destDecimals=18&side=SELL&network=137`

      const response = await fetch(priceUrl, {
        headers: {
          accept: "application/json",
        },
      })

      if (response.ok) {
        const priceData = await response.json()

        if (priceData.priceRoute && priceData.priceRoute.destAmount) {
          // Calculate D.Faith per MATIC
          const dfaithPerMatic = Number(priceData.priceRoute.destAmount) / Math.pow(10, DFAITH_DECIMALS)

          // Get current MATIC price in USD
          const maticResponse = await fetch(
            "https://api.coingecko.com/api/v3/simple/price?ids=matic-network&vs_currencies=usd",
          )
          const maticData = await maticResponse.json()
          const maticPriceUSD = maticData["matic-network"]?.usd || 0.85

          // Calculate D.Faith price in USD
          const dfaithPriceUSD = (maticPriceUSD / dfaithPerMatic).toFixed(6)

          setDfaithPriceUSD(dfaithPriceUSD)

          console.log("✅ Echte DFAITH Preisdaten geladen:", {
            dfaithPerMatic,
            maticPriceUSD,
            dfaithPriceUSD,
          })
          return
        }
      }

      // Fallback to realistic estimate
      console.log("⚠️ ParaSwap Preisdaten nicht verfügbar, verwende Schätzung")
      setDfaithPriceUSD("0.0001")
    } catch (error) {
      console.error("❌ Price loading failed:", error)
      // Keep default values
      setDfaithPriceUSD("0.0001")
    }
  }

  const loadEthersFromCDN = (): Promise<void> => {
    return new Promise((resolve, reject) => {
      if ((window as any).ethers) {
        resolve()
        return
      }

      const script = document.createElement("script")
      script.src = "https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.umd.min.js"
      script.onload = () => {
        console.log("✅ Ethers v5 von CDN geladen")
        resolve()
      }
      script.onerror = () => reject(new Error("Ethers CDN Fehler"))
      document.head.appendChild(script)
    })
  }

  const initializeMagic = async () => {
    try {
      setIsLoading(true)
      setLoadingText("🔧 Initialisiere Magic SDK...")

      // Load Magic SDK from CDN
      if (typeof window !== "undefined" && !(window as any).Magic) {
        await loadMagicFromCDN()
      }

      // Load Ethers v5 from CDN
      if (!(window as any).ethers) {
        await loadEthersFromCDN()
      }

      // Load Web3 for contract interactions
      if (!(window as any).Web3) {
        await loadWeb3FromCDN()
      }

      const MagicSDK = (window as any).Magic
      if (!MagicSDK) {
        throw new Error("Magic SDK konnte nicht geladen werden")
      }

      // Initialize Magic instance
      const magicInstance = new MagicSDK("pk_live_A888A52305FF6188", {
        network: {
          rpcUrl: "https://polygon-rpc.com",
          chainId: 137,
        },
      })

      console.log("✅ Magic SDK initialisiert:", magicInstance)
      setMagic(magicInstance)

      const Web3 = (window as any).Web3
      const web3Instance = new Web3(magicInstance.rpcProvider)
      setWeb3(web3Instance)

      setSdkReady(true)
      setIsLoading(false)

      // Check if user is already logged in
      try {
        const isLoggedIn = await magicInstance.user.isLoggedIn()
        if (isLoggedIn) {
          console.log("👤 Benutzer bereits angemeldet")
          await loadUserData(magicInstance, web3Instance)
        }
      } catch (error) {
        console.log("ℹ️ Benutzer nicht angemeldet oder Fehler beim Überprüfen:", error)
      }
    } catch (error) {
      console.error("❌ Magic SDK Initialisierung fehlgeschlagen:", error)
      setIsLoading(false)
      alert("❌ Fehler beim Laden der Wallet-Bibliotheken. Bitte Seite neu laden.")
    }
  }

  const loadMagicFromCDN = (): Promise<void> => {
    return new Promise((resolve, reject) => {
      if ((window as any).Magic) {
        resolve()
        return
      }

      const script = document.createElement("script")
      script.src = "https://cdn.jsdelivr.net/npm/magic-sdk@latest/dist/magic.js"
      script.onload = () => {
        console.log("✅ Magic SDK von CDN geladen")
        resolve()
      }
      script.onerror = () => reject(new Error("Magic SDK CDN Fehler"))
      document.head.appendChild(script)
    })
  }

  const loadWeb3FromCDN = (): Promise<void> => {
    return new Promise((resolve, reject) => {
      if ((window as any).Web3) {
        resolve()
        return
      }

      const script = document.createElement("script")
      script.src = "https://cdn.jsdelivr.net/npm/web3@latest/dist/web3.min.js"
      script.onload = () => {
        console.log("✅ Web3 von CDN geladen")
        resolve()
      }
      script.onerror = () => reject(new Error("Web3 CDN Fehler"))
      document.head.appendChild(script)
    })
  }

  const loginWithEmail = async () => {
    if (!email || !email.includes("@")) {
      alert("Bitte gib eine gültige E-Mail-Adresse ein.")
      return
    }

    if (!magic || !sdkReady) {
      alert("Magic SDK ist noch nicht bereit. Bitte warte einen Moment.")
      return
    }

    setIsLoading(true)
    setLoadingText("📧 Sende Magic Link an " + email + "...")

    try {
      console.log("🔐 Starte Magic Link Login für:", email)

      await magic.auth.loginWithMagicLink({
        email: email,
        showUI: true,
      })

      setLoadingText("✅ Magic Link bestätigt! Lade Wallet-Daten...")
      await loadUserData(magic, web3)
    } catch (error) {
      console.error("❌ Login fehlgeschlagen:", error)
      setIsLoading(false)

      if (error.message?.includes("User denied")) {
        alert("❌ Login wurde abgebrochen.")
      } else if (error.message?.includes("rate limit")) {
        alert("⏰ Zu viele Versuche. Bitte warte einen Moment.")
      } else {
        alert("❌ Login fehlgeschlagen: " + error.message)
      }
    }
  }

  const loadUserData = async (magicInstance: any, web3Instance: any) => {
    try {
      setLoadingText("👤 Lade Benutzerdaten...")

      const userInfo = await magicInstance.user.getInfo()
      console.log("👤 Benutzer-Info:", userInfo)

      if (!userInfo.publicAddress) {
        const accounts = await web3Instance.eth.getAccounts()
        if (accounts && accounts.length > 0) {
          setWalletAddress(accounts[0])
          setIsLoggedIn(true)
          await loadBalances(accounts[0], web3Instance)
          setIsLoading(false)
          return
        }
        throw new Error("Keine Wallet-Adresse gefunden")
      }

      setWalletAddress(userInfo.publicAddress)
      setIsLoggedIn(true)
      await loadBalances(userInfo.publicAddress, web3Instance)
      setIsLoading(false)
      console.log("✅ Wallet erfolgreich geladen!")
    } catch (error) {
      console.error("❌ Fehler beim Laden der Benutzerdaten:", error)
      setIsLoading(false)
      alert("❌ Fehler beim Laden der Wallet-Daten. Bitte versuche es erneut.")
    }
  }

  const loadBalances = async (address: string, web3Instance: any) => {
    try {
      setLoadingText("💰 Lade Guthaben...")
      console.log("🔍 Lade Balances für Adresse:", address)

      // Load POL balance (native token)
      try {
        const polBalanceWei = await web3Instance.eth.getBalance(address)
        const polBalanceEther = web3Instance.utils.fromWei(polBalanceWei, "ether")
        const formattedPolBalance = Number.parseFloat(polBalanceEther).toFixed(4)
        console.log("💰 POL Balance:", formattedPolBalance)
        setMaticBalance(formattedPolBalance) // Keep same state variable for compatibility
      } catch (error) {
        console.error("❌ POL Balance Fehler:", error)
        setMaticBalance("0.0000")
      }

      // Load D.Faith balance with multiple fallback strategies
      try {
        console.log("📋 DFAITH Contract:", DFAITH_CONTRACT_ADDRESS)

        // Strategy 1: Try with explicit ABI
        const dfaithABI = [
          {
            constant: true,
            inputs: [{ name: "_owner", type: "address" }],
            name: "balanceOf",
            outputs: [{ name: "balance", type: "uint256" }],
            type: "function",
          },
          {
            constant: true,
            inputs: [],
            name: "decimals",
            outputs: [{ name: "", type: "uint8" }],
            type: "function",
          },
        ]

        const contract = new web3Instance.eth.Contract(dfaithABI, DFAITH_CONTRACT_ADDRESS)

        // Get decimals first
        let decimals = DFAITH_DECIMALS
        try {
          decimals = await contract.methods.decimals().call()
          console.log("🔢 DFAITH Decimals from contract:", decimals)
        } catch (decError) {
          console.log("⚠️ Using default decimals:", DFAITH_DECIMALS)
        }

        const dfaithBalanceRaw = await contract.methods.balanceOf(address).call()
        console.log("🔢 DFAITH Raw Balance:", dfaithBalanceRaw)
        console.log("🔢 DFAITH Raw Balance (string):", dfaithBalanceRaw.toString())

        if (dfaithBalanceRaw && dfaithBalanceRaw !== "0") {
          const dfaithBalanceFormatted = (Number(dfaithBalanceRaw) / Math.pow(10, 18)).toFixed(4)
          console.log("💰 DFAITH Balance:", dfaithBalanceFormatted)
          setDfaithBalance(dfaithBalanceFormatted)
        } else {
          console.log("ℹ️ DFAITH Balance ist 0")
          setDfaithBalance("0.00")
        }
      } catch (error) {
        console.error("❌ DFAITH Balance Fehler:", error)

        // Fallback: Try direct RPC call
        try {
          console.log("🔄 Versuche direkten RPC Call...")
          const balanceOfSignature = "0x70a08231" // balanceOf(address)
          const paddedAddress = address.slice(2).padStart(64, "0")
          const data = balanceOfSignature + paddedAddress

          const result = await web3Instance.eth.call({
            to: DFAITH_CONTRACT_ADDRESS,
            data: data,
          })

          console.log("📞 Direct RPC Result:", result)

          if (result && result !== "0x") {
            const balance = web3Instance.utils.hexToNumber(result)
            const formattedBalance = (balance / Math.pow(10, DFAITH_DECIMALS)).toFixed(2)
            console.log("💰 DFAITH Balance (RPC):", formattedBalance)
            setDfaithBalance(formattedBalance)
          } else {
            setDfaithBalance("0.00")
          }
        } catch (rpcError) {
          console.error("❌ RPC Fallback auch fehlgeschlagen:", rpcError)
          setDfaithBalance("0.00")
        }
      }
      // Load D.INVEST balance
      try {
        console.log("📋 D.INVEST Contract:", DINVEST_CONTRACT_ADDRESS)

        const dinvestABI = [
          {
            constant: true,
            inputs: [{ name: "_owner", type: "address" }],
            name: "balanceOf",
            outputs: [{ name: "balance", type: "uint256" }],
            type: "function",
          },
        ]

        const dinvestContract = new web3Instance.eth.Contract(dinvestABI, DINVEST_CONTRACT_ADDRESS)
        const dinvestBalanceRaw = await dinvestContract.methods.balanceOf(address).call()

        console.log("🔢 D.INVEST Raw Balance:", dinvestBalanceRaw)

        if (dinvestBalanceRaw && dinvestBalanceRaw !== "0") {
          // D.INVEST has 0 decimals, so no division needed
          const dinvestBalanceFormatted = dinvestBalanceRaw.toString()
          console.log("💰 D.INVEST Balance:", dinvestBalanceFormatted)
          setDinvestBalance(dinvestBalanceFormatted)
        } else {
          console.log("ℹ️ D.INVEST Balance ist 0")
          setDinvestBalance("0")
        }
      } catch (error) {
        console.error("❌ D.INVEST Balance Fehler:", error)
        setDinvestBalance("0")
      }
      // Load staking data
      await loadStakingData(address, web3Instance)
    } catch (error) {
      console.error("❌ Allgemeiner Balance-Fehler:", error)
      setMaticBalance("0.0000")
      setDfaithBalance("0.00")
    }
  }

  const loadStakingData = async (address: string, web3Instance: any) => {
    try {
      console.log("📊 Lade Staking-Daten für:", address)

      const stakingABI = [
        {
          constant: true,
          inputs: [{ name: "account", type: "address" }],
          name: "userInfo",
          outputs: [{ name: "stakedAmount", type: "uint256" }],
          type: "function",
        },
        {
          constant: true,
          inputs: [{ name: "account", type: "address" }],
          name: "earned",
          outputs: [{ name: "", type: "uint256" }],
          type: "function",
        },
        {
          constant: false,
          inputs: [{ name: "amount", type: "uint256" }],
          name: "stake",
          outputs: [],
          type: "function",
        },
        {
          constant: false,
          inputs: [],
          name: "claimReward",
          outputs: [],
          type: "function",
        },
        {
          constant: false,
          inputs: [{ name: "amount", type: "uint256" }],
          name: "withdraw",
          outputs: [],
          type: "function",
        },
      ]

      const stakingContract = new web3Instance.eth.Contract(stakingABI, STAKING_CONTRACT_ADDRESS)

      // Lade gestakte D.INVEST Menge mit userInfo
      try {
        console.log("🔍 Prüfe gestakte D.INVEST Menge mit userInfo...")
        const userInfo = await stakingContract.methods.userInfo(address).call()
        console.log("🔒 UserInfo (raw):", userInfo)
        console.log("🔒 UserInfo stakedAmount (string):", userInfo.toString())

        // D.INVEST hat 0 Decimals, also direkt verwenden
        const formattedStaked = userInfo.toString()
        setStakedDinvestAmount(formattedStaked)
        console.log("✅ Gestakte D.INVEST gesetzt:", formattedStaked)
      } catch (error) {
        console.error("❌ Fehler beim Laden der gestakten Menge:", error)
        setStakedDinvestAmount("0")
      }

      // Lade angesammelte D.Faith Rewards mit mehreren Versuchen
      try {
        console.log("🔍 Prüfe angesammelte DFAITH Rewards...")
        const earnedRewards = await stakingContract.methods.earned(address).call()
        console.log("🎁 Angesammelte DFAITH Rewards (raw):", earnedRewards)
        console.log("🎁 Angesammelte DFAITH Rewards (string):", earnedRewards.toString())

        if (earnedRewards && earnedRewards !== "0") {
          const formattedRewards = (Number(earnedRewards) / Math.pow(10, DFAITH_DECIMALS)).toFixed(18)
          setEarnedDfaithRewards(formattedRewards)
          console.log("✅ DFAITH Rewards gesetzt:", formattedRewards)
        } else {
          console.log("ℹ️ Keine DFAITH Rewards vorhanden")
          setEarnedDfaithRewards("0.000000000000000000")
        }
      } catch (error) {
        console.error("❌ Fehler beim Laden der Rewards:", error)
        setEarnedDfaithRewards("0.000000000000000000")
      }

      // Zusätzliche Contract-Validierung
      try {
        console.log("🔍 Validiere Staking Contract...")
        const contractCode = await web3Instance.eth.getCode(STAKING_CONTRACT_ADDRESS)
        if (contractCode === "0x") {
          console.error("❌ Staking Contract existiert nicht!")
          alert("⚠️ Staking Contract nicht gefunden. Möglicherweise ist das Contract noch nicht deployed.")
        } else {
          console.log("✅ Staking Contract validiert")
        }
      } catch (error) {
        console.error("❌ Contract-Validierung fehlgeschlagen:", error)
      }
    } catch (error) {
      console.error("❌ Allgemeiner Staking-Daten Fehler:", error)
      setStakedDinvestAmount("0")
      setEarnedDfaithRewards("0.000000000000000000")
    }
  }

  // BUY FUNCTIONALITY - OpenOcean v3 als primär, ParaSwap als Fallback
  const loadBuyQuote = async () => {
    if (!buyAmount || Number.parseFloat(buyAmount) <= 0) {
      alert("Bitte gib einen gültigen POL Betrag ein.")
      return
    }

    if (Number.parseFloat(buyAmount) > Number.parseFloat(maticBalance) - 0.01) {
      alert("Nicht genügend POL Guthaben (0.01 POL für Gas reserviert).")
      return
    }

    setIsLoading(true)
    setLoadingText("🔄 Lade POL zu DFAITH Quote...")

    try {
      const buyAmountFloat = Number.parseFloat(buyAmount)
      const amountInWei = web3.utils.toWei(buyAmountFloat.toString(), "ether")

      console.log("💱 POL Buy Request:", {
        buyAmount: buyAmountFloat,
        amountInWei,
        walletAddress,
      })

      // Strategy 1: Try OpenOcean v3 for POL to D.Faith (PRIMARY) - KORRIGIERT
      setLoadingText("🥇 Versuche OpenOcean v3 für POL zu DFAITH...")

      try {
        // OpenOcean v3 für native POL zu D.Faith - KORRIGIERT
        const nativePolAddress = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE"

        // OpenOcean v3 API - Korrekte Parameter MIT gasPrice
        const openOceanUrl = `https://open-api.openocean.finance/v3/137/swap_quote?inTokenAddress=${nativePolAddress}&outTokenAddress=${DFAITH_CONTRACT_ADDRESS}&amount=${buyAmountFloat}&slippage=1&account=${walletAddress}&gasPrice=30000000000`

        console.log("📞 OpenOcean v3 POL Buy URL:", openOceanUrl)

        const response = await fetch(openOceanUrl, {
          headers: {
            accept: "application/json",
            "User-Agent": "D.Faith-Wallet/1.0",
          },
        })

        const responseText = await response.text()
        console.log("📋 OpenOcean v3 POL Buy Response:", {
          status: response.status,
          bodyLength: responseText.length,
          bodyPreview: responseText.substring(0, 500),
        })

        if (response.ok) {
          const swapData = JSON.parse(responseText)
          console.log("📋 OpenOcean v3 POL Buy Parsed:", swapData)

          if (swapData.code && swapData.code !== 200) {
            console.log("❌ OpenOcean v3 Error Code:", swapData.code, swapData.message)
            throw new Error(`OpenOcean Error: ${swapData.code} - ${swapData.message}`)
          }

          // OpenOcean v3 Response Format korrigiert
          if (swapData.data && swapData.data.outAmount) {
            const formattedData = {
              srcToken: { symbol: "POL", address: nativePolAddress, decimals: 18 },
              dstToken: { symbol: "DFAITH", address: DFAITH_CONTRACT_ADDRESS, decimals: 18 },
              dstAmount: swapData.data.outAmount,
              estimatedGas: swapData.data.estimatedGas || "300000",
              // TX-Daten für späteren Abruf speichern, nicht direkt verwenden
              openOceanData: {
                inTokenAddress: nativePolAddress,
                outTokenAddress: DFAITH_CONTRACT_ADDRESS,
                amount: buyAmountFloat,
                slippage: 1,
                account: walletAddress,
                gasPrice: 30000000000, // 30 Gwei
              },
              priceSource: "OpenOcean v3",
              isRealQuote: true,
              requiresWrap: false, // Native POL, kein Wrapping nötig
            }

            setBuyQuote(formattedData)
            const outputAmount = (Number(swapData.data.outAmount) / Math.pow(10, 18)).toFixed(4)
            const rate = (Number.parseFloat(outputAmount) / buyAmountFloat).toFixed(4)

            setIsLoading(false)
            alert(
              `✅ OpenOcean v3 Buy-Quote erhalten!\n\nWechselkurs: 1 POL = ${rate} DFAITH\nDu erhältst: ${outputAmount} DFAITH\n✅ Direkt mit nativem POL!`,
            )
            return
          } else {
            console.log("❌ OpenOcean v3: Fehlende Felder in Antwort")
            throw new Error("OpenOcean v3: Unvollständige Antwort")
          }
        } else {
          throw new Error(`OpenOcean v3 API error: ${response.status}`)
        }
      } catch (error) {
        console.log("❌ OpenOcean v3 POL buy failed:", error.message)
      }

      // Strategy 2: Try ParaSwap for POL to D.Faith (FALLBACK)
      setLoadingText("🥈 Versuche ParaSwap als Fallback...")

      try {
        // ParaSwap benötigt WPOL, also mit Wrapping
        const priceUrl = `https://apiv5.paraswap.io/prices?srcToken=${WPOL_CONTRACT_ADDRESS}&destToken=${DFAITH_CONTRACT_ADDRESS}&amount=${amountInWei}&srcDecimals=18&destDecimals=18&side=SELL&network=137`

        console.log("📞 ParaSwap POL Buy URL:", priceUrl)

        const response = await fetch(priceUrl, {
          headers: {
            accept: "application/json",
          },
        })

        if (response.ok) {
          const priceData = await response.json()

          if (priceData.priceRoute && priceData.priceRoute.destAmount) {
            const formattedData = {
              srcToken: { symbol: "POL", address: NATIVE_POL_ADDRESS, decimals: 18 },
              dstToken: { symbol: "DFAITH", address: DFAITH_CONTRACT_ADDRESS, decimals: 18 },
              dstAmount: priceData.priceRoute.destAmount,
              estimatedGas: priceData.priceRoute.gasCost || "400000",
              priceRoute: priceData.priceRoute,
              requiresWrap: true, // Flag für POL → WPOL wrapping
              priceSource: "ParaSwap v5",
              isRealQuote: true,
            }

            setBuyQuote(formattedData)
            const outputAmount = (Number(priceData.priceRoute.destAmount) / Math.pow(10, 18)).toFixed(4)
            const rate = (Number.parseFloat(outputAmount) / buyAmountFloat).toFixed(4)

            setIsLoading(false)
            alert(
              `✅ ParaSwap Buy-Quote erhalten!\n\nWechselkurs: 1 POL = ${rate} DFAITH\nDu erhältst: ${outputAmount} DFAITH\n\n🔄 POL wird automatisch zu WPOL wrapped!`,
            )
            return
          }
        }
      } catch (error) {
        console.log("❌ ParaSwap POL buy failed:", error.message)
      }

      // Strategy 3: Fallback
      const fallbackQuote = {
        srcToken: { symbol: "POL", address: NATIVE_POL_ADDRESS, decimals: 18 },
        dstToken: { symbol: "DFAITH", address: DFAITH_CONTRACT_ADDRESS, decimals: 18 },
        dstAmount: Math.floor(buyAmountFloat * 10000 * Math.pow(10, DFAITH_DECIMALS)).toString(),
        estimatedGas: "250000",
        requiresWrap: true,
        priceSource: "Fallback-Estimator",
        isRealQuote: false,
        isFallback: true,
      }

      setBuyQuote(fallbackQuote)
      setIsLoading(false)
      alert("⚠️ Fallback-Quote erstellt!")
    } catch (error) {
      console.error("❌ POL Buy Fehler:", error)
      setIsLoading(false)
      alert(`❌ Kritischer Fehler: ${error.message}`)
    }
  }

  // POL zu D.Faith Buy-Swap implementieren - OpenOcean v3 KORRIGIERT
  const executeBuySwapFn = async () => {
    if (!buyQuote) {
      alert("Bitte lade eine Quote zuerst.")
      return
    }

    setIsLoading(true)
    setLoadingText("🔄 Führe POL zu DFAITH Swap aus...")

    try {
      const magic = new (window as any).Magic("pk_live_A888A52305FF6188", {
        network: {
          rpcUrl: "https://polygon-rpc.com",
          chainId: 137,
        },
      })

      const provider = new (window as any).ethers.providers.Web3Provider(magic.rpcProvider)
      const signer = provider.getSigner()

      const buyAmountWei = web3.utils.toWei(buyAmount, "ether")

      // OpenOcean v3 - Korrekte Implementierung mit frischen TX-Daten
      if (buyQuote.priceSource === "OpenOcean v3" && buyQuote.openOceanData) {
        setLoadingText("🔄 OpenOcean v3: Hole frische Transaktionsdaten...")

        // Hole frische TX-Daten mit aktueller Nonce UND gasPrice
        const swapUrl = `https://open-api.openocean.finance/v3/137/swap_quote?inTokenAddress=${buyQuote.openOceanData.inTokenAddress}&outTokenAddress=${buyQuote.openOceanData.outTokenAddress}&amount=${buyQuote.openOceanData.amount}&slippage=${buyQuote.openOceanData.slippage}&account=${buyQuote.openOceanData.account}&gasPrice=30000000000`

        console.log("📞 OpenOcean v3 Fresh TX URL:", swapUrl)

        const swapResponse = await fetch(swapUrl, {
          headers: {
            accept: "application/json",
            "User-Agent": "D.Faith-Wallet/1.0",
          },
        })

        if (!swapResponse.ok) {
          throw new Error(`OpenOcean v3 TX API error: ${swapResponse.status}`)
        }

        const freshSwapData = await swapResponse.json()
        console.log("📋 OpenOcean v3 Fresh TX Data:", freshSwapData)

        if (freshSwapData.data && freshSwapData.data.data && freshSwapData.data.to) {
          setLoadingText("🔄 OpenOcean v3 Direkter POL Swap...")

          // Verwende frische TX-Daten
          const tx = await signer.sendTransaction({
            to: freshSwapData.data.to,
            data: freshSwapData.data.data,
            value: (window as any).ethers.BigNumber.from(buyAmountWei),
            gasLimit: freshSwapData.data.estimatedGas?.toString() || "300000",
            // Nonce wird automatisch von ethers verwaltet
          })

          setLoadingText("⏳ Warte auf OpenOcean v3 Swap-Bestätigung...")
          await tx.wait()
          console.log("✅ OpenOcean v3 POL zu DFAITH Swap abgeschlossen")
        } else {
          throw new Error("OpenOcean v3: Keine gültigen Transaktionsdaten erhalten")
        }
      }
      // ParaSwap - Mit Wrapping (unverändert)
      else if (buyQuote.requiresWrap) {
        // Step 1: Wrap POL to WPOL
        setLoadingText("🔄 Schritt 1: POL zu WPOL wrappen...")

        const wpolContract = new (window as any).ethers.Contract(
          WPOL_CONTRACT_ADDRESS,
          ["function deposit() payable"],
          signer,
        )

        const wrapTx = await wpolContract.deposit({
          value: (window as any).ethers.BigNumber.from(buyAmountWei),
        })

        setLoadingText("⏳ Warte auf POL Wrap-Bestätigung...")
        await wrapTx.wait()
        console.log("✅ POL zu WPOL wrapped")

        // Step 2: Approve WPOL for ParaSwap
        setLoadingText("🔄 Schritt 2: WPOL für ParaSwap freigeben...")

        const wpolApproveContract = new (window as any).ethers.Contract(
          WPOL_CONTRACT_ADDRESS,
          ["function approve(address spender, uint256 amount) returns (bool)"],
          signer,
        )

        const approveTx = await wpolApproveContract.approve(
          PARASWAP_TOKEN_TRANSFER_PROXY,
          (window as any).ethers.constants.MaxUint256,
        )

        setLoadingText("⏳ Warte auf WPOL Approve-Bestätigung...")
        await approveTx.wait()
        console.log("✅ WPOL für ParaSwap freigegeben")

        // Step 3: Generate and execute ParaSwap transaction
        setLoadingText("🔄 Schritt 3: ParaSwap Swap (WPOL → DFAITH)...")

        const txUrl = "https://apiv5.paraswap.io/transactions/137"
        const txResponse = await fetch(txUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            srcToken: WPOL_CONTRACT_ADDRESS,
            destToken: DFAITH_CONTRACT_ADDRESS,
            srcAmount: buyAmountWei,
            priceRoute: buyQuote.priceRoute,
            userAddress: walletAddress,
            slippage: 100, // 1%
          }),
        })

        const txData = await txResponse.json()

        const swapTx = await signer.sendTransaction({
          to: txData.to,
          data: txData.data,
          value: "0", // No POL value needed for WPOL swap
        })

        setLoadingText("⏳ Warte auf ParaSwap Swap-Bestätigung...")
        await swapTx.wait()
        console.log("✅ WPOL zu DFAITH Swap abgeschlossen")
      }

      // Refresh balances
      await loadBalances(walletAddress, web3)

      // Reset modal
      setBuyAmount("")
      setBuyQuote(null)
      setIsMaticApproved(false)
      setShowMaticBuyModal(false)
      setIsLoading(false)

      const successMessage =
        buyQuote.priceSource === "OpenOcean v3"
          ? "✅ OpenOcean v3 POL zu DFAITH Swap erfolgreich!\n\n🚀 Direkter nativer POL Swap\n\nDeine Guthaben wurden aktualisiert."
          : "✅ ParaSwap POL zu DFAITH Swap erfolgreich!\n\n1. POL → WPOL (Wrap)\n2. WPOL freigegeben\n3. WPOL → DFAITH (ParaSwap)\n\nDeine Guthaben wurden aktualisiert."

      alert(successMessage)
    } catch (error) {
      console.error("❌ Buy-Swap Fehler:", error)
      setIsLoading(false)

      if (error.message?.includes("nonce")) {
        alert(
          "❌ Nonce-Fehler bei OpenOcean!\n\nVersuche es in ein paar Sekunden erneut oder nutze ParaSwap als Alternative.",
        )
      } else if (error.message?.includes("User denied") || error.message?.includes("rejected")) {
        alert("❌ Transaktion wurde vom Benutzer abgebrochen.")
      } else if (error.message?.includes("insufficient funds")) {
        alert("❌ Nicht genügend POL für Swap oder Gas-Gebühren.")
      } else {
        alert("❌ Fehler beim Buy-Swap: " + error.message)
      }
    }
  }

  // SELL FUNCTIONALITY - Nur ParaSwap API mit verbesserter Allowance-Behandlung
  const loadSellQuote = async () => {
    if (!sellAmount || Number.parseFloat(sellAmount) <= 0) {
      alert("Bitte gib einen gültigen Betrag ein.")
      return
    }

    if (Number.parseFloat(sellAmount) > Number.parseFloat(dfaithBalance)) {
      alert("Nicht genügend DFAITH Guthaben.")
      return
    }

    setIsLoading(true)
    setLoadingText("🔍 Lade ParaSwap Quote für DFAITH zu WPOL...")

    try {
      const sellAmountFloat = Number.parseFloat(sellAmount)
      const amountInSmallestUnit = Math.floor(sellAmountFloat * Math.pow(10, 18))

      console.log("💱 ParaSwap Quote Request (DFAITH → WPOL):", {
        sellAmountFloat,
        amountInSmallestUnit,
        walletAddress,
      })

      // ParaSwap Price API - D.Faith zu WPOL
      const priceUrl = `https://apiv5.paraswap.io/prices?srcToken=${DFAITH_CONTRACT_ADDRESS}&destToken=${WPOL_CONTRACT_ADDRESS}&amount=${amountInSmallestUnit}&srcDecimals=18&destDecimals=18&side=SELL&network=137`

      console.log("📞 ParaSwap Price URL (DFAITH → WPOL):", priceUrl)

      const response = await fetch(priceUrl, {
        headers: {
          accept: "application/json",
        },
        timeout: 10000,
      })

      const responseText = await response.text()
      console.log("📋 ParaSwap Response:", {
        status: response.status,
        bodyLength: responseText.length,
        bodyPreview: responseText.substring(0, 500),
      })

      if (!response.ok) {
        throw new Error(`ParaSwap API error: ${response.status} - ${responseText}`)
      }

      const priceData = JSON.parse(responseText)

      if (!priceData.priceRoute || !priceData.priceRoute.destAmount) {
        throw new Error("ParaSwap: Invalid price response")
      }

      console.log("✅ ParaSwap Price Data:", priceData)

      // Store quote WITH unwrapping flag
      const formattedQuote = {
        srcToken: {
          symbol: "DFAITH",
          address: DFAITH_CONTRACT_ADDRESS,
          decimals: 18,
        },
        dstToken: {
          symbol: "WPOL",
          address: WPOL_CONTRACT_ADDRESS,
          decimals: 18,
        },
        dstAmount: priceData.priceRoute.destAmount,
        estimatedGas: priceData.priceRoute.gasCost || "400000",
        protocols: [
          {
            name: "ParaSwap v5",
            part: 100,
            fromTokenAddress: DFAITH_CONTRACT_ADDRESS,
            toTokenAddress: WPOL_CONTRACT_ADDRESS,
          },
        ],
        priceRoute: priceData.priceRoute,
        tx: null,
        priceSource: "ParaSwap v5",
        isRealQuote: true,
        timestamp: new Date().toISOString(),
        requiresUnwrap: true, // Flag für automatisches Unwrapping
      }

      setSellQuote(formattedQuote)
      const outputAmount = web3.utils.fromWei(priceData.priceRoute.destAmount, "ether")
      const rate = (Number.parseFloat(outputAmount) / sellAmountFloat).toFixed(8)

      setIsLoading(false)

      alert(
        `✅ ParaSwap Quote erhalten!\n\nWechselkurs: 1 DFAITH = ${rate} WPOL\nDu erhältst: ${outputAmount} WPOL\n\n🔄 WPOL wird automatisch zu POL unwrapped!`,
      )
    } catch (error) {
      console.error("❌ ParaSwap Quote Fehler:", error)
      setIsLoading(false)

      if (error.message.includes("ESTIMATED_LOSS_GREATER_THAN_MAX_IMPACT")) {
        alert("❌ ParaSwap: Zu hoher Preis-Impact!\n\nVersuche einen kleineren Betrag.")
      } else if (error.message.includes("No routes found")) {
        alert("❌ ParaSwap: Keine Liquidität für DFAITH gefunden!\n\nDFAITH hat sehr geringe Liquidität auf DEXs.")
      } else {
        alert(`❌ ParaSwap Fehler: ${error.message}`)
      }
    }
  }

  // Generate transaction data AFTER approval is confirmed
  const generateTransactionData = async () => {
    if (!sellQuote || !sellQuote.priceRoute) {
      throw new Error("No price route available")
    }

    setLoadingText("🔄 Generiere ParaSwap Transaktionsdaten...")

    const sellAmountFloat = Number.parseFloat(sellAmount)
    const amountInSmallestUnit = Math.floor(sellAmountFloat * Math.pow(10, 18))

    const txUrl = "https://apiv5.paraswap.io/transactions/137"
    const txResponse = await fetch(txUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        srcToken: DFAITH_CONTRACT_ADDRESS,
        destToken: WPOL_CONTRACT_ADDRESS,
        srcAmount: amountInSmallestUnit.toString(),
        priceRoute: sellQuote.priceRoute,
        userAddress: walletAddress,
        slippage: 100, // 1%
        partner: "paraswap.io",
        partnerAddress: "0x0000000000000000000000000000000000000000",
        partnerFeeBps: 0,
        takeSurplus: false,
      }),
      timeout: 15000,
    })

    const txResponseText = await txResponse.text()
    console.log("📋 ParaSwap TX Response:", {
      status: txResponse.status,
      bodyLength: txResponseText.length,
      bodyPreview: txResponseText.substring(0, 500),
    })

    if (!txResponse.ok) {
      throw new Error(`ParaSwap TX API error: ${txResponse.status} - ${txResponseText}`)
    }

    const txResponseData = JSON.parse(txResponseText)

    return {
      to: txResponseData.to,
      data: txResponseData.data,
      value: txResponseData.value || "0",
      gasLimit: "500000", // Erhöhtes Gas-Limit für ParaSwap
    }
  }

  // ParaSwap-spezifischer Approve-Mechanismus - KORRIGIERT mit besserer Validierung
  const approveDFaith = async () => {
    if (!sellQuote) {
      alert("Bitte lade zuerst eine ParaSwap Quote.")
      return
    }

    setIsLoading(true)
    setLoadingText("🔍 Prüfe aktuelle ParaSwap Allowance...")

    try {
      // Magic und ethers lokal initialisieren
      const magic = new (window as any).Magic("pk_live_A888A52305FF6188", {
        network: {
          rpcUrl: "https://polygon-rpc.com",
          chainId: 137,
        },
      })

      const provider = new (window as any).ethers.providers.Web3Provider(magic.rpcProvider)
      const signer = provider.getSigner()

      console.log("📋 ParaSwap Approve Details:", {
        tokenAddress: DFAITH_CONTRACT_ADDRESS,
        spenderAddress: PARASWAP_TOKEN_TRANSFER_PROXY,
        sellAmount: sellAmount,
      })

      const tokenContract = new (window as any).ethers.Contract(
        DFAITH_CONTRACT_ADDRESS,
        [
          "function approve(address spender, uint256 amount) public returns (bool)",
          "function allowance(address owner, address spender) public view returns (uint256)",
        ],
        signer,
      )

      const sellAmountWei = Math.floor(Number.parseFloat(sellAmount) * Math.pow(10, 18))

      // Schritt 1: Prüfe aktuelle Allowance
      const currentAllowance = await tokenContract.allowance(walletAddress, PARASWAP_TOKEN_TRANSFER_PROXY)

      console.log("📊 ParaSwap Allowance Check:", {
        currentAllowance: currentAllowance.toString(),
        requiredAmount: sellAmountWei.toString(),
        spender: PARASWAP_TOKEN_TRANSFER_PROXY,
      })

      // Prüfe ob bereits genügend Allowance vorhanden ist
      if (currentAllowance.gte(sellAmountWei)) {
        console.log("✅ Genügend ParaSwap Allowance bereits vorhanden!")
        setIsApproved(true)
        setIsLoading(false)
        alert(
          `✅ DFAITH bereits für ParaSwap freigegeben!\n\nAktuelle Allowance: ${(window as any).ethers.utils.formatUnits(currentAllowance, DFAITH_DECIMALS)} DFAITH\nSpender: ParaSwap TokenTransferProxy\n\nJetzt kannst du den Swap ausführen.`,
        )
        return
      }

      // Schritt 2: Reset Allowance auf 0 (für manche Token erforderlich)
      setLoadingText("🔄 Reset ParaSwap Allowance auf 0...")

      try {
        const resetTx = await tokenContract.approve(PARASWAP_TOKEN_TRANSFER_PROXY, 0)
        setLoadingText("⏳ Warte auf Reset-Bestätigung...")
        await resetTx.wait()
        console.log("✅ ParaSwap Allowance auf 0 gesetzt")

        // Kurz warten nach Reset
        await new Promise((resolve) => setTimeout(resolve, 5000))
      } catch (resetError) {
        console.log("⚠️ ParaSwap Reset nicht erforderlich:", resetError.message)
      }

      // Schritt 3: Setze MaxUint256 Allowance für bessere Kompatibilität
      setLoadingText("🔓 Setze MaxUint256 Allowance für ParaSwap...")

      console.log("📊 Setting ParaSwap MaxUint256 Allowance:", {
        spender: PARASWAP_TOKEN_TRANSFER_PROXY,
        amount: "MaxUint256",
      })

      const approveTx = await tokenContract.approve(
        PARASWAP_TOKEN_TRANSFER_PROXY,
        (window as any).ethers.constants.MaxUint256,
      )

      setLoadingText("⏳ Warte auf ParaSwap Approve-Bestätigung...")
      const approveReceipt = await approveTx.wait()

      console.log("✅ ParaSwap Approve TX bestätigt:", approveReceipt)

      // Schritt 4: Validiere neue Allowance mit mehreren Versuchen
      setLoadingText("🔍 Validiere ParaSwap Allowance...")

      let newAllowance
      let attempts = 0
      const maxAttempts = 5

      while (attempts < maxAttempts) {
        await new Promise((resolve) => setTimeout(resolve, 3000)) // Warte 3 Sekunden zwischen Versuchen

        try {
          newAllowance = await tokenContract.allowance(walletAddress, PARASWAP_TOKEN_TRANSFER_PROXY)

          console.log(`📊 Allowance Check Attempt ${attempts + 1}:`, {
            newAllowance: newAllowance.toString(),
            requiredAmount: sellAmountWei.toString(),
            isEnough: newAllowance.gte(sellAmountWei),
          })

          if (newAllowance.gte(sellAmountWei)) {
            break // Allowance ist ausreichend
          }
        } catch (error) {
          console.log(`❌ Allowance check attempt ${attempts + 1} failed:`, error.message)
        }

        attempts++
      }

      if (newAllowance && newAllowance.gte(sellAmountWei)) {
        setIsApproved(true)
        setIsLoading(false)
        alert(
          `✅ DFAITH erfolgreich für ParaSwap freigegeben!\n\nNeue Allowance: MaxUint256\nSpender: ParaSwap TokenTransferProxy\nTX: ${approveTx.hash}\n\n✅ ParaSwap Swap ist bereit!`,
        )
      } else {
        setIsLoading(false)
        alert(
          `⚠️ ParaSwap Allowance gesetzt, aber Validierung fehlgeschlagen!\n\nBitte warte 30 Sekunden und versuche den Swap.\nFalls das Problem weiterhin besteht, lade eine neue Quote.`,
        )
        // Setze trotzdem approved auf true, da die TX bestätigt wurde
        setIsApproved(true)
      }
    } catch (error) {
      console.error("❌ ParaSwap Approve Fehler:", error)
      setIsLoading(false)

      if (error.message?.includes("User denied")) {
        alert("❌ Transaktion wurde abgebrochen.")
      } else if (error.message?.includes("insufficient funds")) {
        alert("❌ Nicht genügend POL für Gas-Gebühren.")
      } else {
        alert(`❌ ParaSwap Approve Fehler: ${error.message}\n\nVersuche es erneut.`)
      }
    }
  }

  // Verbesserte executeSwap Funktion mit Transaction Data Generation nach Approval
  const executeSwap = async () => {
    if (!sellQuote || !isApproved) {
      alert("Bitte lade eine ParaSwap Quote und genehmige DFAITH zuerst.")
      return
    }

    setIsLoading(true)
    setLoadingText("🔍 Finale ParaSwap Allowance-Prüfung...")

    try {
      const magic = new (window as any).Magic("pk_live_A888A52305FF6188", {
        network: {
          rpcUrl: "https://polygon-rpc.com",
          chainId: 137,
        },
      })

      const provider = new (window as any).ethers.providers.Web3Provider(magic.rpcProvider)
      const signer = provider.getSigner()

      const tokenContract = new (window as any).ethers.Contract(
        DFAITH_CONTRACT_ADDRESS,
        ["function allowance(address owner, address spender) public view returns (uint256)"],
        signer,
      )

      const sellAmountWei = Math.floor(Number.parseFloat(sellAmount) * Math.pow(10, 18))

      // Finale Allowance-Prüfung
      const finalAllowance = await tokenContract.allowance(walletAddress, PARASWAP_TOKEN_TRANSFER_PROXY)

      console.log("🔍 Finale ParaSwap Allowance Check:", {
        finalAllowance: finalAllowance.toString(),
        requiredAmount: sellAmountWei.toString(),
        spender: PARASWAP_TOKEN_TRANSFER_PROXY,
      })

      if (finalAllowance.lt(sellAmountWei)) {
        setIsLoading(false)
        alert(
          `❌ ParaSwap Allowance Problem!\n\nBenötigt: ${sellAmountWei} DFAITH\nVorhanden: ${finalAllowance.toString()}\n\n💡 Lösung: Approve erneut für ParaSwap`,
        )
        setIsApproved(false)
        return
      }

      // Generate transaction data
      let txData
      try {
        txData = await generateTransactionData()
        console.log("✅ ParaSwap TX Data generiert:", txData)
      } catch (txError) {
        setIsLoading(false)
        alert(
          `❌ Fehler beim Generieren der Transaktionsdaten:\n\n${txError.message}\n\nVersuche eine neue Quote zu laden.`,
        )
        return
      }

      // Step 1: Execute ParaSwap (DFAITH → WPOL)
      setLoadingText("🔄 Schritt 1: ParaSwap Swap (DFAITH → WPOL)...")

      const swapTx = await signer.sendTransaction({
        to: txData.to,
        data: txData.data,
        value: (window as any).ethers.BigNumber.from(txData.value || "0"),
        gasLimit: txData.gasLimit,
      })

      setLoadingText("⏳ Warte auf ParaSwap Swap-Bestätigung...")
      const swapReceipt = await swapTx.wait()
      console.log("✅ ParaSwap Swap bestätigt:", swapReceipt)

      // Step 2: Unwrap WPOL to POL (if required)
      if (sellQuote.requiresUnwrap) {
        setLoadingText("🔄 Schritt 2: WPOL zu POL unwrappen...")

        // Get WPOL balance
        const wpolContract = new (window as any).ethers.Contract(
          WPOL_CONTRACT_ADDRESS,
          ["function balanceOf(address owner) view returns (uint256)", "function withdraw(uint256 amount) public"],
          signer,
        )

        const wpolBalance = await wpolContract.balanceOf(walletAddress)
        console.log("💰 WPOL Balance nach Swap:", wpolBalance.toString())

        if (wpolBalance.gt(0)) {
          // Unwrap all WPOL to POL
          const unwrapTx = await wpolContract.withdraw(wpolBalance)
          setLoadingText("⏳ Warte auf WPOL Unwrap-Bestätigung...")
          await unwrapTx.wait()
          console.log("✅ WPOL zu POL unwrapped")
        }
      }

      // Refresh balances
      await loadBalances(walletAddress, web3)

      // Reset modal
      setSellAmount("")
      setSellQuote(null)
      setIsApproved(false)
      setShowSellModal(false)
      setIsLoading(false)

      alert(
        `✅ Swap erfolgreich abgeschlossen!\n\n1. DFAITH → WPOL (ParaSwap)\n2. WPOL → POL (Unwrap)\n\nTX Hash: ${swapTx.hash}\n\nDu hast jetzt native POL erhalten!`,
      )
    } catch (error) {
      console.error("❌ Swap Fehler:", error)
      setIsLoading(false)

      if (error.message?.includes("User denied") || error.message?.includes("rejected")) {
        alert("❌ Transaktion wurde vom Benutzer abgebrochen.")
      } else if (error.message?.includes("insufficient funds")) {
        alert("❌ Nicht genügend Guthaben oder POL für Gas-Gebühren.")
      } else {
        alert("❌ Swap Fehler: " + error.message)
      }
    }
  }

  // Stake D.INVEST Tokens - Verbessert mit Nonce-Management
  const executeStake = async () => {
    if (!stakeAmount || Number.parseFloat(stakeAmount) <= 0) {
      alert("Bitte gib einen gültigen Stake-Betrag ein.")
      return
    }

    const stakeAmountInt = Math.floor(Number.parseFloat(stakeAmount))
    if (stakeAmountInt > Number.parseFloat(dinvestBalance)) {
      alert("Nicht genügend D.INVEST Guthaben.")
      return
    }

    setIsLoading(true)
    setLoadingText("🔒 Stake D.INVEST Tokens...")

    try {
      const magic = new (window as any).Magic("pk_live_A888A52305FF6188", {
        network: {
          rpcUrl: "https://polygon-rpc.com",
          chainId: 137,
        },
      })

      const provider = new (window as any).ethers.providers.Web3Provider(magic.rpcProvider)
      const signer = provider.getSigner()

      // Erweiterte ABI für bessere Kompatibilität
      const dinvestABI = [
        "function approve(address spender, uint256 amount) returns (bool)",
        "function allowance(address owner, address spender) view returns (uint256)",
        "function balanceOf(address owner) view returns (uint256)",
      ]

      const stakingABI = [
        "function stake(uint256 amount) external",
        "function userInfo(address account) external view returns (uint256)",
        "function earned(address account) external view returns (uint256)",
      ]

      console.log("🔍 Staking Details:", {
        stakeAmount: stakeAmountInt,
        dinvestContract: DINVEST_CONTRACT_ADDRESS,
        stakingContract: STAKING_CONTRACT_ADDRESS,
        walletAddress,
      })

      // Step 1: Check current allowance
      setLoadingText("🔍 Prüfe D.INVEST Allowance...")

      const dinvestContract = new (window as any).ethers.Contract(DINVEST_CONTRACT_ADDRESS, dinvestABI, signer)

      const currentAllowance = await dinvestContract.allowance(walletAddress, STAKING_CONTRACT_ADDRESS)
      console.log("📊 Current D.INVEST Allowance:", currentAllowance.toString())

      // Step 2: Approve if needed
      if (currentAllowance.lt(stakeAmountInt)) {
        setLoadingText("🔓 D.INVEST für Staking freigeben...")

        // Get current nonce to avoid conflicts
        const currentNonce = await provider.getTransactionCount(walletAddress, "pending")
        console.log("🔢 Current Nonce for Approve:", currentNonce)

        const approveTx = await dinvestContract.approve(STAKING_CONTRACT_ADDRESS, stakeAmountInt, {
          nonce: currentNonce,
          gasLimit: 100000, // Standard gas limit for approve
        })

        setLoadingText("⏳ Warte auf Approve-Bestätigung...")
        await approveTx.wait()
        console.log("✅ D.INVEST für Staking freigegeben")

        // Wait a bit for blockchain state update
        await new Promise((resolve) => setTimeout(resolve, 3000))
      } else {
        console.log("✅ Genügend D.INVEST Allowance bereits vorhanden")
      }

      // Step 3: Validate staking contract before staking
      setLoadingText("🔍 Validiere Staking Contract...")

      const stakingContract = new (window as any).ethers.Contract(STAKING_CONTRACT_ADDRESS, stakingABI, signer)

      // Check if contract exists
      const contractCode = await provider.getCode(STAKING_CONTRACT_ADDRESS)
      if (contractCode === "0x") {
        throw new Error("Staking Contract existiert nicht auf dieser Adresse")
      }

      // Try to call a view function to validate contract
      try {
        await stakingContract.userInfo(walletAddress)
        console.log("✅ Staking Contract validiert")
      } catch (viewError) {
        console.error("❌ Staking Contract Validierung fehlgeschlagen:", viewError)
        throw new Error("Staking Contract ist nicht kompatibel oder nicht deployed")
      }

      // Step 4: Execute stake with fresh nonce
      setLoadingText("🔒 Stake D.INVEST Tokens...")

      // Get fresh nonce for staking transaction
      const stakeNonce = await provider.getTransactionCount(walletAddress, "pending")
      console.log("🔢 Fresh Nonce for Stake:", stakeNonce)

      const stakeTx = await stakingContract.stake(stakeAmountInt, {
        nonce: stakeNonce,
        gasLimit: 200000, // Increased gas limit for staking
      })

      setLoadingText("⏳ Warte auf Stake-Bestätigung...")
      const stakeReceipt = await stakeTx.wait()
      console.log("✅ D.INVEST Tokens gestaked:", stakeReceipt)

      // Refresh balances and staking data
      await loadBalances(walletAddress, web3)

      // Reset form
      setStakeAmount("")
      setIsLoading(false)

      alert(
        `✅ Erfolgreich ${stakeAmountInt} D.INVEST gestaked!\n\nTX Hash: ${stakeTx.hash}\n\nDeine Tokens verdienen jetzt DFAITH Rewards.`,
      )
    } catch (error) {
      console.error("❌ Stake Fehler:", error)
      setIsLoading(false)

      if (error.message?.includes("User denied") || error.message?.includes("rejected")) {
        alert("❌ Transaktion wurde vom Benutzer abgebrochen.")
      } else if (error.message?.includes("insufficient funds")) {
        alert("❌ Nicht genügend POL für Gas-Gebühren.")
      } else if (error.message?.includes("nonce")) {
        alert("❌ Nonce-Fehler!\n\nBitte warte 30 Sekunden und versuche es erneut.\n\nDetails: " + error.message)
      } else if (error.code === "UNPREDICTABLE_GAS_LIMIT") {
        alert(
          "❌ Gas-Schätzung fehlgeschlagen!\n\nMögliche Gründe:\n• Staking Contract noch nicht deployed\n• Nicht genügend D.INVEST Balance\n• Contract-Funktion würde fehlschlagen\n\nBitte prüfe dein D.INVEST Guthaben und versuche es später erneut.",
        )
      } else if (error.message?.includes("execution reverted")) {
        alert(
          "❌ Smart Contract Fehler!\n\nMögliche Gründe:\n• Staking Contract Problem\n• Nicht genügend Allowance\n• Contract-Zustand ungültig\n\nDetails: " +
            error.message,
        )
      } else {
        alert("❌ Fehler beim Staken: " + error.message)
      }
    }
  }

  // Unstake D.INVEST Tokens - Verbessert mit Nonce-Management
  const executeUnstake = async () => {
    if (!unstakeAmount || Number.parseFloat(unstakeAmount) <= 0) {
      alert("Bitte gib einen gültigen Unstake-Betrag ein.")
      return
    }

    const unstakeAmountInt = Math.floor(Number.parseFloat(unstakeAmount))
    if (unstakeAmountInt > Number.parseFloat(stakedDinvestAmount)) {
      alert("Nicht genügend gestakte D.INVEST Tokens.")
      return
    }

    setIsLoading(true)
    setLoadingText("🔓 Unstake D.INVEST Tokens...")

    try {
      const magic = new (window as any).Magic("pk_live_A888A52305FF6188", {
        network: {
          rpcUrl: "https://polygon-rpc.com",
          chainId: 137,
        },
      })

      const provider = new (window as any).ethers.providers.Web3Provider(magic.rpcProvider)
      const signer = provider.getSigner()

      const stakingContract = new (window as any).ethers.Contract(
        STAKING_CONTRACT_ADDRESS,
        ["function withdraw(uint256 amount) external"],
        signer,
      )

      // Get fresh nonce
      const currentNonce = await provider.getTransactionCount(walletAddress, "pending")
      console.log("🔢 Fresh Nonce for Unstake:", currentNonce)

      const withdrawTx = await stakingContract.withdraw(unstakeAmountInt, {
        nonce: currentNonce,
        gasLimit: 150000,
      })

      setLoadingText("⏳ Warte auf Unstake-Bestätigung...")
      await withdrawTx.wait()
      console.log("✅ D.INVEST Tokens unstaked")

      // Refresh balances and staking data
      await loadBalances(walletAddress, web3)

      // Reset form
      setUnstakeAmount("")
      setIsLoading(false)

      alert(
        `✅ Erfolgreich ${unstakeAmountInt} D.INVEST unstaked!\n\nTX Hash: ${withdrawTx.hash}\n\nDeine Tokens sind wieder verfügbar.`,
      )
    } catch (error) {
      console.error("❌ Unstake Fehler:", error)
      setIsLoading(false)

      if (error.message?.includes("User denied") || error.message?.includes("rejected")) {
        alert("❌ Transaktion wurde vom Benutzer abgebrochen.")
      } else if (error.message?.includes("insufficient funds")) {
        alert("❌ Nicht genügend POL für Gas-Gebühren.")
      } else if (error.message?.includes("nonce")) {
        alert("❌ Nonce-Fehler!\n\nBitte warte 30 Sekunden und versuche es erneut.")
      } else if (error.code === "UNPREDICTABLE_GAS_LIMIT") {
        alert(
          "❌ Gas-Schätzung fehlgeschlagen!\n\nMögliche Gründe:\n• Keine gestakten Tokens vorhanden\n• Staking Contract Problem\n\nBitte prüfe deine gestakten Tokens.",
        )
      } else {
        alert("❌ Fehler beim Unstaken: " + error.message)
      }
    }
  }

  // Claim D.Faith Rewards - Verbessert mit Nonce-Management und besserer Validierung
  const claimRewards = async () => {
    console.log("🎁 Claim Rewards gestartet...")
    console.log("🔍 Aktuelle Rewards:", earnedDfaithRewards)

    const rewardsAmount = Number.parseFloat(earnedDfaithRewards)

    if (rewardsAmount <= 0.0001) {
      alert(
        `❌ Keine Rewards zum Claimen verfügbar.\n\nAktuelle Rewards: ${earnedDfaithRewards} DFAITH\n\n💡 Du musst erst D.INVEST staken um Rewards zu verdienen.`,
      )
      return
    }

    setIsLoading(true)
    setLoadingText("🎁 Claime DFAITH Rewards...")

    try {
      const magic = new (window as any).Magic("pk_live_A888A52305FF6188", {
        network: {
          rpcUrl: "https://polygon-rpc.com",
          chainId: 137,
        },
      })

      const provider = new (window as any).ethers.providers.Web3Provider(magic.rpcProvider)
      const signer = provider.getSigner()

      const stakingABI = [
        "function claimReward() external",
        "function earned(address account) external view returns (uint256)",
        "function userInfo(address account) external view returns (uint256)",
      ]

      const stakingContract = new (window as any).ethers.Contract(STAKING_CONTRACT_ADDRESS, stakingABI, signer)

      console.log("🔍 Finale Rewards-Prüfung vor Claim...")

      // Validate contract and rewards
      try {
        const currentRewards = await stakingContract.earned(walletAddress)
        console.log("🎁 Aktuelle Rewards im Contract:", currentRewards.toString())

        if (currentRewards.isZero()) {
          setIsLoading(false)
          alert(
            "❌ Keine Rewards im Smart Contract gefunden!\n\nMögliche Gründe:\n• Du hast noch keine D.INVEST gestaked\n• Rewards wurden bereits geclaimt\n• Staking-Periode noch nicht begonnen",
          )
          return
        }

        const rewardsInDFaith = (window as any).ethers.utils.formatUnits(currentRewards, DFAITH_DECIMALS)
        console.log("🎁 Rewards in DFAITH:", rewardsInDFaith)
      } catch (rewardCheckError) {
        console.error("❌ Rewards-Prüfung fehlgeschlagen:", rewardCheckError)
        setIsLoading(false)
        alert("❌ Fehler beim Prüfen der Rewards:\n\n" + rewardCheckError.message)
        return
      }

      console.log("🔄 Führe claimReward() aus...")

      // Get fresh nonce
      const currentNonce = await provider.getTransactionCount(walletAddress, "pending")
      console.log("🔢 Fresh Nonce for Claim:", currentNonce)

      // Claim with fresh nonce and increased gas limit
      const claimTx = await stakingContract.claimReward({
        nonce: currentNonce,
        gasLimit: 200000, // Increased gas limit
      })

      setLoadingText("⏳ Warte auf Claim-Bestätigung...")
      const receipt = await claimTx.wait()
      console.log("✅ DFAITH Rewards geclaimt:", receipt)

      // Refresh balances and staking data
      await loadBalances(walletAddress, web3)

      setIsLoading(false)

      alert(
        `✅ Erfolgreich ${earnedDfaithRewards} DFAITH Rewards geclaimt!\n\nTX Hash: ${claimTx.hash}\n\nDeine DFAITH Balance wurde aktualisiert.`,
      )
    } catch (error) {
      console.error("❌ Claim Fehler:", error)
      setIsLoading(false)

      if (error.message?.includes("User denied") || error.message?.includes("rejected")) {
        alert("❌ Transaktion wurde vom Benutzer abgebrochen.")
      } else if (error.message?.includes("insufficient funds")) {
        alert("❌ Nicht genügend POL für Gas-Gebühren.")
      } else if (error.message?.includes("nonce")) {
        alert("❌ Nonce-Fehler!\n\nBitte warte 30 Sekunden und versuche es erneut.")
      } else if (error.message?.includes("execution reverted")) {
        alert(
          "❌ Smart Contract Fehler!\n\nMögliche Gründe:\n• Keine Rewards verfügbar\n• Contract-Zustand ungültig\n• Staking-Periode noch nicht begonnen\n\nDetails: " +
            error.message,
        )
      } else if (error.code === "UNPREDICTABLE_GAS_LIMIT") {
        alert(
          "❌ Gas-Schätzung fehlgeschlagen!\n\nDas bedeutet meist:\n• Keine Rewards zum Claimen\n• Contract-Funktion würde fehlschlagen\n• Staking Contract Problem\n\nVersuche erst D.INVEST zu staken.",
        )
      } else {
        alert("❌ Fehler beim Claimen: " + error.message)
      }
    }
  }

  // Transaktionshistorie - Korrigierte URL
  const loadTransactionHistory = async () => {
    if (!walletAddress) return

    setIsLoading(true)
    setLoadingText("📜 Lade Transaktionshistorie...")

    try {
      // Load normal transactions - KORRIGIERTE URL
      const normalTxUrl = `https://api.polygonscan.com/api?module=account&action=txlist&address=${walletAddress}&startblock=0&endblock=99999999&page=1&offset=10&sort=desc&apikey=${POLYGONSCAN_API_KEY}`

      // Load ERC20 token transfers
      const tokenTxUrl = `https://api.polygonscan.com/api?module=account&action=tokentx&address=${walletAddress}&startblock=0&endblock=99999999&page=1&offset=10&sort=desc&apikey=${POLYGONSCAN_API_KEY}`

      console.log("📞 Loading transaction history:", { normalTxUrl, tokenTxUrl })

      const [normalResponse, tokenResponse] = await Promise.all([fetch(normalTxUrl), fetch(tokenTxUrl)])

      const normalData = await normalResponse.json()
      const tokenData = await tokenResponse.json()

      console.log("📜 Normal Transactions:", normalData)
      console.log("🪙 Token Transactions:", tokenData)

      const allTransactions = []

      // Process normal transactions
      if (normalData.status === "1" && normalData.result) {
        normalData.result.forEach((tx: any) => {
          allTransactions.push({
            hash: tx.hash,
            type: "POL",
            from: tx.from,
            to: tx.to,
            value: (Number(tx.value) / Math.pow(10, 18)).toFixed(4),
            timestamp: new Date(Number(tx.timeStamp) * 1000).toLocaleString(),
            status: tx.txreceipt_status === "1" ? "Success" : "Failed",
            gasUsed: tx.gasUsed,
          })
        })
      }

      // Process token transactions
      if (tokenData.status === "1" && tokenData.result) {
        tokenData.result.forEach((tx: any) => {
          allTransactions.push({
            hash: tx.hash,
            type: tx.tokenSymbol || "Token",
            from: tx.from,
            to: tx.to,
            value: (Number(tx.value) / Math.pow(10, Number(tx.tokenDecimal))).toFixed(4),
            timestamp: new Date(Number(tx.timeStamp) * 1000).toLocaleString(),
            status: "Success",
            gasUsed: tx.gasUsed,
            contractAddress: tx.contractAddress,
          })
        })
      }

      // Sort by timestamp (newest first)
      allTransactions.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

      setTransactions(allTransactions.slice(0, 20))
      setIsLoading(false)
    } catch (error) {
      console.error("❌ Fehler beim Laden der Transaktionshistorie:", error)
      setIsLoading(false)
      alert("❌ Fehler beim Laden der Transaktionshistorie: " + error.message)
    }
  }

  // SEND FUNCTIONALITY - Fixed contract creation
  const executeSend = async () => {
    if (!sendAddress || !sendAmount) {
      alert("Bitte fülle alle Felder aus.")
      return
    }

    if (!web3.utils.isAddress(sendAddress)) {
      alert("Ungültige Empfänger-Adresse.")
      return
    }

    const amount = Number.parseFloat(sendAmount)
    if (amount <= 0) {
      alert("Ungültiger Betrag.")
      return
    }

    setIsLoading(true)
    setLoadingText("➡️ Sende Transaktion...")

    try {
      // Magic und ethers lokal initialisieren wie in HTML
      const magic = new (window as any).Magic("pk_live_A888A52305FF6188", {
        network: {
          rpcUrl: "https://polygon-rpc.com",
          chainId: 137,
        },
      })

      // Ethers v5 Provider wie in HTML
      const provider = new (window as any).ethers.providers.Web3Provider(magic.rpcProvider)
      const signer = provider.getSigner()

      if (sendToken === "matic") {
        // Send MATIC mit ethers
        const amountWei = (window as any).ethers.utils.parseEther(sendAmount)

        const tx = await signer.sendTransaction({
          to: sendAddress,
          value: amountWei,
        })

        console.log("✅ POL gesendet:", tx)
        await tx.wait()
      } else if (sendToken === "dfaith") {
        // Send D.Faith mit ethers Contract
        console.log("🔄 Creating DFAITH contract for transfer...")

        const contract = new (window as any).ethers.Contract(
          DFAITH_CONTRACT_ADDRESS,
          ["function transfer(address to, uint256 amount) returns (bool)"],
          signer,
        )

        const amountWei = Math.floor(amount * Math.pow(10, 18)).toString()
        console.log("💰 Transfer amount:", amountWei)

        const tx = await contract.transfer(sendAddress, amountWei)
        console.log("✅ DFAITH gesendet:", tx)
        await tx.wait()
      } else if (sendToken === "dinvest") {
        // Send D.INVEST mit ethers Contract
        console.log("🔄 Creating D.INVEST contract for transfer...")

        const contract = new (window as any).ethers.Contract(
          DINVEST_CONTRACT_ADDRESS,
          ["function transfer(address to, uint256 amount) returns (bool)"],
          signer,
        )

        // D.INVEST has 0 decimals, so use amount directly
        const amountToSend = Math.floor(amount).toString()
        console.log("💰 D.INVEST Transfer amount:", amountToSend)

        const tx = await contract.transfer(sendAddress, amountToSend)
        console.log("✅ D.INVEST gesendet:", tx)
        await tx.wait()
      }

      // Refresh balances
      await loadBalances(walletAddress, web3)

      // Reset modal
      setSendAmount("")
      setSendAddress("")
      setShowSendModal(false)
      setIsLoading(false)

      alert("✅ Transaktion erfolgreich gesendet!")
    } catch (error) {
      console.error("❌ Send-Fehler:", error)
      setIsLoading(false)

      if (error.message?.includes("User denied") || error.message?.includes("rejected")) {
        alert("❌ Transaktion wurde vom Benutzer abgebrochen.")
      } else if (error.message?.includes("insufficient funds")) {
        alert("❌ Nicht genügend Guthaben oder POL für Gas-Gebühren.")
      } else {
        alert("❌ Fehler beim Senden: " + error.message)
      }
    }
  }

  const logout = async () => {
    if (!magic) return

    try {
      setIsLoading(true)
      setLoadingText("🚪 Abmelden...")

      await magic.user.logout()

      // Clear auto-refresh interval
      if (refreshInterval) {
        clearInterval(refreshInterval)
        setRefreshInterval(null)
      }

      setIsLoggedIn(false)
      setWalletAddress("")
      setDfaithBalance("0.00")
      setMaticBalance("0.00")
      setDinvestBalance("0")
      setStakedDinvestAmount("0")
      setEarnedDfaithRewards("0.00")
      setEmail("")

      setIsLoading(false)
      console.log("✅ Erfolgreich abgemeldet")
    } catch (error) {
      console.error("❌ Logout fehlgeschlagen:", error)
      setIsLoading(false)
    }
  }

  const copyWalletAddress = async () => {
    try {
      await navigator.clipboard.writeText(walletAddress)
      alert("✅ Wallet-Adresse wurde kopiert!")
    } catch (error) {
      console.error("❌ Kopieren fehlgeschlagen:", error)
      alert("❌ Kopieren fehlgeschlagen.")
    }
  }

  const formatAddressFn = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`
  }

  const refreshBalances = async () => {
    if (!web3 || !walletAddress) return

    setIsLoading(true)
    setLoadingText("🔄 Aktualisiere Guthaben...")

    try {
      await loadBalances(walletAddress, web3)
      await loadPriceData() // Refresh prices too
    } catch (error) {
      console.error("❌ Fehler beim Aktualisieren:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const setMaxSendAmount = () => {
    if (sendToken === "matic") {
      // Reserve some MATIC for gas fees
      const maxAmount = Math.max(0, Number.parseFloat(maticBalance) - 0.01)
      setSendAmount(maxAmount.toFixed(4))
    } else if (sendToken === "dfaith") {
      setSendAmount(dfaithBalance)
    } else if (sendToken === "dinvest") {
      setSendAmount(dinvestBalance)
    }
  }

  const setMaxStakeAmount = () => {
    setStakeAmount(dinvestBalance)
  }

  const setMaxUnstakeAmount = () => {
    setUnstakeAmount(stakedDinvestAmount)
  }

  // Format rewards display
  const formatRewards = (rewards: string) => {
    const rewardsFloat = Number.parseFloat(rewards)
    if (showFullRewards) {
      return rewards
    } else {
      return rewardsFloat.toFixed(4)
    }
  }

 // Render Wallet Tab Content
  const renderWalletContent = () => {
    if (!isLoggedIn) {
      return (
        <div className="flex justify-center items-center min-h-[70vh] px-4">
          <Card className="w-full max-w-md bg-gradient-to-br from-purple-900/20 to-pink-900/20 backdrop-blur-lg border border-purple-500/30 shadow-2xl">
            <CardContent className="p-6 sm:p-8 text-center">
              <div className="mb-6 sm:mb-8">
                <div className="text-6xl mb-4">🎵</div>
                <h1 className="text-2xl sm:text-3xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  Dawid Faith Wallet
                </h1>
                <p className="text-gray-300 text-base sm:text-lg mb-4">
                  Sichere Blockchain-Wallet für Fans & Investoren
                </p>
                {!sdkReady && <p className="text-purple-400 text-sm animate-pulse">⏳ Lade Magic SDK...</p>}
              </div>

              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Deine E-Mail-Adresse"
                className="mb-6 text-center bg-white/10 backdrop-blur-sm text-white placeholder-gray-400 text-base sm:text-lg py-3 sm:py-4 border border-purple-500/50 rounded-xl"
                style={{ fontSize: "16px" }}
                disabled={!sdkReady}
              />

              <Button
                onClick={loginWithEmail}
                disabled={!sdkReady || isLoading}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-3 sm:py-4 rounded-xl text-base sm:text-lg shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105"
              >
                {sdkReady ? "🔐 Magic Link senden" : "⏳ Lädt..."}
              </Button>

              <div className="mt-6 text-sm text-gray-300 space-y-2">
                <p className="text-purple-300">✨ Du erhältst einen Magic Link per E-Mail</p>
                <p className="text-pink-300">🔗 Klicke darauf um dich anzumelden</p>
                <p className="text-blue-300">🔒 Keine Passwörter erforderlich</p>
                <div className="mt-4 p-3 bg-yellow-500/20 border border-yellow-400/30 rounded-lg backdrop-blur-sm">
                  <p className="text-yellow-300 font-medium">📱 Social Media Apps:</p>
                  <p className="text-yellow-200 text-xs">
                    Falls der Login nicht sofort klappt, einfach nochmal versuchen. Der Browser lädt nicht mehr neu nach
                    dem 2. Versuch.
                  </p>
                </div>
              </div>

              <p className="text-xs text-gray-400 mt-6">Powered by Magic SDK • Polygon Network</p>
            </CardContent>
          </Card>
        </div>
      )
    }

    return (
      <div className="flex justify-center px-4">
        <Card className="w-full max-w-2xl bg-gradient-to-br from-purple-900/30 to-pink-900/30 backdrop-blur-lg border border-purple-500/30 text-white shadow-2xl">
          <CardContent className="p-4 sm:p-8 relative">
            {/* Logout Button */}
            <Button
              onClick={logout}
              className="absolute top-2 sm:top-4 right-2 sm:right-4 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold px-3 sm:px-4 py-2 sm:py-3 rounded-xl text-sm sm:text-base shadow-lg transform hover:scale-105 transition-all duration-300"
            >
              Logout
            </Button>

            {/* POL Badge */}
            <div className="absolute top-2 sm:top-4 left-2 sm:left-4 bg-purple-500/30 backdrop-blur-sm rounded-2xl px-2 sm:px-4 py-1 sm:py-2 text-xs sm:text-sm font-bold text-purple-200 flex items-center gap-1 sm:gap-2 shadow-lg border border-purple-400/30">
              <span>{maticBalance || "0.0000"} POL</span>
            </div>

            {/* Wallet Address Section */}
            <div className="text-center mt-16 sm:mt-20 mb-6 sm:mb-8">
              <p className="text-purple-300 text-sm sm:text-base mb-2 font-medium">Wallet-Adresse:</p>
              <div className="flex justify-center items-center gap-3 bg-white/10 backdrop-blur-sm rounded-xl p-3 sm:p-4 shadow-inner border border-white/20">
                <span className="font-mono text-sm sm:text-lg text-gray-200">{formatAddressFn(walletAddress)}</span>
                <Button
                  onClick={copyWalletAddress}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-4 sm:px-6 py-2 rounded-full font-bold shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
                >
                  Kopieren
                </Button>
              </div>
            </div>

            {/* Balance Display */}
            <div className="text-center mb-8 sm:mb-10">
              <div
                className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-3"
                style={{ minHeight: "3rem" }}
              >
                {dfaithBalance || "0.00"} DFAITH
              </div>
              <div className="text-lg sm:text-xl text-purple-300">
                ≈ ${(Number.parseFloat(dfaithBalance || "0") * Number.parseFloat(dfaithPriceUSD)).toFixed(2)} USD
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-6">
              <Button
                onClick={() => setShowBuyModal(true)}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold py-3 sm:py-4 rounded-xl text-sm sm:text-lg shadow-lg transform hover:scale-105 transition-all duration-300"
              >
                <span className="text-white">💰</span> Kaufen
              </Button>
              <Button
                onClick={() => setShowSellModal(true)}
                className="bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 text-white font-bold py-3 sm:py-4 rounded-xl text-sm sm:text-lg shadow-lg transform hover:scale-105 transition-all duration-300"
              >
                💲 Verkaufen
              </Button>
              <Button
                onClick={() => setShowSendModal(true)}
                className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white font-bold py-3 sm:py-4 rounded-xl text-sm sm:text-lg shadow-lg transform hover:scale-105 transition-all duration-300"
              >
                ➡️ Senden
              </Button>
              <Button
                onClick={() => {
                  setShowHistoryModal(true)
                  loadTransactionHistory()
                }}
                className="bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold py-3 sm:py-4 rounded-xl text-sm sm:text-lg shadow-lg transform hover:scale-105 transition-all duration-300"
              >
                📜 Historie
              </Button>
            </div>

            {/* D.INVEST Balance Display */}
            <div className="text-center p-4 bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm rounded-xl border border-blue-400/30">
              <div className="text-xl sm:text-2xl font-bold text-blue-300 mb-2">{dinvestBalance || "0"} D.INVEST</div>

              {Number.parseFloat(stakedDinvestAmount) > 0 && (
                <div className="text-sm text-green-400 mb-3">🔒 Gestaked: {stakedDinvestAmount} D.INVEST</div>
              )}

              <Button
                onClick={() => setShowStakingModal(true)}
                className="bg-gradient-to-r from-blue-600 to-purple-700 hover:from-blue-700 hover:to-purple-800 text-white font-bold py-2 px-4 sm:px-6 rounded-full shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
              >
                🔒 Stake & Earn
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Render other tab contents with artist theme
  const renderTokenomicsContent = () => {
    return (
      <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8 px-4">
        <div className="text-center py-20">
          <div className="text-6xl mb-6">📊</div>
          <h1 className="text-3xl sm:text-4xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            Tokenomics
          </h1>
          <p className="text-lg text-gray-300 mb-8">Die Zukunft der Musik-Ökonomie</p>
          <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 backdrop-blur-lg border border-purple-500/30 rounded-2xl p-8 max-w-md mx-auto">
            <p className="text-purple-300">Coming Soon...</p>
          </div>
        </div>
      </div>
    )
  }

  const renderInstagramContent = () => {
    return (
      <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8 px-4">
        <div className="text-center py-20">
          <div className="text-6xl mb-6">📸</div>
          <h1 className="text-3xl sm:text-4xl font-bold mb-4 bg-gradient-to-r from-pink-400 to-rose-400 bg-clip-text text-transparent">
            Instagram
          </h1>
          <p className="text-lg text-gray-300 mb-8">Folge meiner musikalischen Reise</p>
          <div className="bg-gradient-to-r from-pink-900/30 to-rose-900/30 backdrop-blur-lg border border-pink-500/30 rounded-2xl p-8 max-w-md mx-auto">
            <p className="text-pink-300">Coming Soon...</p>
          </div>
        </div>
      </div>
    )
  }

  const renderFacebookContent = () => {
    return (
      <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8 px-4">
        <div className="text-center py-20">
          <div className="text-6xl mb-6">👥</div>
          <h1 className="text-3xl sm:text-4xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
            Facebook
          </h1>
          <p className="text-lg text-gray-300 mb-8">Verbinde dich mit der Community</p>
          <div className="bg-gradient-to-r from-blue-900/30 to-indigo-900/30 backdrop-blur-lg border border-blue-500/30 rounded-2xl p-8 max-w-md mx-auto">
            <p className="text-blue-300">Coming Soon...</p>
          </div>
        </div>
      </div>
    )
  }

  const renderTikTokContent = () => {
    return (
      <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8 px-4">
        <div className="text-center py-20">
          <div className="text-6xl mb-6">🎬</div>
          <h1 className="text-3xl sm:text-4xl font-bold mb-4 bg-gradient-to-r from-gray-200 to-gray-400 bg-clip-text text-transparent">
            TikTok
          </h1>
          <p className="text-lg text-gray-300 mb-8">Kurze Clips, große Emotionen</p>
          <div className="bg-gradient-to-r from-gray-900/30 to-black/30 backdrop-blur-lg border border-gray-500/30 rounded-2xl p-8 max-w-md mx-auto">
            <p className="text-gray-300">Coming Soon...</p>
          </div>
        </div>
      </div>
    )
  }

  const renderMerchContent = () => {
    return (
      <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8 px-4">
        <div className="text-center py-20">
          <div className="text-6xl mb-6">🛍️</div>
          <h1 className="text-3xl sm:text-4xl font-bold mb-4 bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
            Merch Store
          </h1>
          <p className="text-lg text-gray-300 mb-8">Exklusive Artikel für echte Fans</p>
          <div className="bg-gradient-to-r from-green-900/30 to-emerald-900/30 backdrop-blur-lg border border-green-500/30 rounded-2xl p-8 max-w-md mx-auto">
            <p className="text-green-300">Coming Soon...</p>
          </div>
        </div>
      </div>
    )
  }

  const renderLiveContent = () => {
    return (
      <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8 px-4">
        <div className="text-center py-20">
          <div className="text-6xl mb-6">🔴</div>
          <h1 className="text-3xl sm:text-4xl font-bold mb-4 bg-gradient-to-r from-red-400 to-rose-400 bg-clip-text text-transparent">
            Live Streams
          </h1>
          <p className="text-lg text-gray-300 mb-8">Erlebe Musik in Echtzeit</p>
          <div className="bg-gradient-to-r from-red-900/30 to-rose-900/30 backdrop-blur-lg border border-red-500/30 rounded-2xl p-8 max-w-md mx-auto">
            <p className="text-red-300">Coming Soon...</p>
          </div>
        </div>
      </div>
    )
  }

  const renderStreamerContent = () => {
    return (
      <div className="max-w-6xl mx-auto space-y-6 sm:space-y-8 px-4">
        <div className="text-center py-20">
          <div className="text-6xl mb-6">🎮</div>
          <h1 className="text-3xl sm:text-4xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">
            Gaming & Streams
          </h1>
          <p className="text-lg text-gray-300 mb-8">Musik trifft Gaming</p>
          <div className="bg-gradient-to-r from-purple-900/30 to-indigo-900/30 backdrop-blur-lg border border-purple-500/30 rounded-2xl p-8 max-w-md mx-auto">
            <p className="text-purple-300">Coming Soon...</p>
          </div>
        </div>
      </div>
    )
  }

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (showSocialDropdown && !event.target.closest(".relative")) {
        setShowSocialDropdown(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [showSocialDropdown])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {isLoading && <LoadingOverlay text={loadingText} />}

      {/* Navigation Header - Brand Icons */}
      <div className="bg-gradient-to-r from-purple-900/80 via-pink-900/80 to-purple-900/80 backdrop-blur-lg shadow-2xl border-b border-purple-500/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center items-center py-3 sm:py-4">
            {/* Navigation Icons */}
            <div className="flex items-center space-x-2 sm:space-x-4 bg-white/10 backdrop-blur-sm rounded-2xl p-2 sm:p-3 border border-white/20">
              <button
                onClick={() => setActiveTab("tokenomics")}
                className={`p-2 sm:p-3 rounded-xl font-medium transition-all ${
                  activeTab === "tokenomics"
                    ? "bg-gradient-to-r from-purple-500 to-pink-500 shadow-lg scale-110"
                    : "hover:bg-white/10 hover:scale-105"
                }`}
                title="Tokenomics"
              >
                <div className="text-2xl sm:text-3xl">📊</div>
              </button>

              <button
                onClick={() => setActiveTab("wallet")}
                className={`p-2 sm:p-3 rounded-xl font-medium transition-all ${
                  activeTab === "wallet"
                    ? "bg-gradient-to-r from-purple-500 to-pink-500 shadow-lg scale-110"
                    : "hover:bg-white/10 hover:scale-105"
                }`}
                title="Wallet"
              >
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-br from-yellow-400 to-amber-500 rounded-full flex items-center justify-center text-[6px] sm:text-[7px] font-bold text-white">
  DFAITH
</div>
              </button>

              <button
                onClick={() => setActiveTab("instagram")}
                className={`p-2 sm:p-3 rounded-xl font-medium transition-all ${
                  activeTab === "instagram"
                    ? "bg-gradient-to-r from-pink-500 to-rose-500 shadow-lg scale-110"
                    : "hover:bg-white/10 hover:scale-105"
                }`}
                title="Instagram"
              >
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 rounded-lg flex items-center justify-center">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 sm:w-5 sm:h-5 text-white fill-current">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                  </svg>
                </div>
              </button>

              <button
                onClick={() => setActiveTab("facebook")}
                className={`p-2 sm:p-3 rounded-xl font-medium transition-all ${
                  activeTab === "facebook"
                    ? "bg-gradient-to-r from-blue-500 to-indigo-500 shadow-lg scale-110"
                    : "hover:bg-white/10 hover:scale-105"
                }`}
                title="Facebook"
              >
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 sm:w-5 sm:h-5 text-white fill-current">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                </div>
              </button>

              <button
                onClick={() => setActiveTab("tiktok")}
                className={`p-2 sm:p-3 rounded-xl font-medium transition-all ${
                  activeTab === "tiktok"
                    ? "bg-gradient-to-r from-gray-600 to-gray-800 shadow-lg scale-110"
                    : "hover:bg-white/10 hover:scale-105"
                }`}
                title="TikTok"
              >
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-black rounded-lg flex items-center justify-center">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 sm:w-5 sm:h-5 text-white fill-current">
                    <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
                  </svg>
                </div>
              </button>

              <button
                onClick={() => setActiveTab("merch")}
                className={`p-2 sm:p-3 rounded-xl font-medium transition-all ${
                  activeTab === "merch"
                    ? "bg-gradient-to-r from-green-500 to-emerald-500 shadow-lg scale-110"
                    : "hover:bg-white/10 hover:scale-105"
                }`}
                title="Merch Store"
              >
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-br from-orange-400 to-orange-600 rounded-lg flex items-center justify-center">
  <svg viewBox="0 0 24 24" className="w-5 h-5 sm:w-6 sm:h-6 text-white fill-current">
    <path d="M16.5 2L15 4H9L7.5 2L3 5.5V7L6 8.5V21C6 21.55 6.45 22 7 22H17C17.55 22 18 21.55 18 21V8.5L21 7V5.5L16.5 2Z" />
  </svg>
</div>
              </button>

              <button
                onClick={() => setActiveTab("live")}
                className={`p-2 sm:p-3 rounded-xl font-medium transition-all ${
                  activeTab === "live"
                    ? "bg-gradient-to-r from-red-500 to-rose-500 shadow-lg scale-110"
                    : "hover:bg-white/10 hover:scale-105"
                }`}
                title="Live Streams"
              >
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-red-600 rounded-lg flex items-center justify-center">
                  <svg viewBox="0 0 24 24" className="w-4 h-4 sm:w-5 sm:h-5 text-white fill-current">
                    <path d="M17,10.5V7A1,1 0 0,0 16,6H4A1,1 0 0,0 3,7V17A1,1 0 0,0 4,18H16A1,1 0 0,0 17,17V13.5L21,17.5V6.5L17,10.5Z" />
                  </svg>
                </div>
              </button>

              <button
                onClick={() => setActiveTab("streamer")}
                className={`p-2 sm:p-3 rounded-xl font-medium transition-all ${
                  activeTab === "streamer"
                    ? "bg-gradient-to-r from-purple-500 to-indigo-500 shadow-lg scale-110"
                    : "hover:bg-white/10 hover:scale-105"
                }`}
                title="Spotify"
              >
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-[#1DB954] rounded-lg flex items-center justify-center">
  <svg viewBox="0 0 24 24" className="w-4 h-4 sm:w-5 sm:h-5 text-white fill-current">
    <path d="M12 0C5.37125 0 0 5.37125 0 12C0 18.6288 5.37125 24 12 24C18.6288 24 24 18.6288 24 12C24 5.37125 18.6288 0 12 0ZM17.3412 17.3412C17.0712 17.71 16.5712 17.7962 16.2025 17.5262C13.1225 15.36 8.69625 14.9813 4.97375 15.9838C4.53875 16.1012 4.08625 15.84 3.96875 15.3963C3.85125 14.9613 4.1125 14.5088 4.55625 14.3913C8.76875 13.2675 13.77 13.69 17.3562 16.1887C17.7338 16.4525 17.8175 16.9725 17.3412 17.3412ZM18.6225 14.01C18.2725 14.4837 17.6112 14.5937 17.1375 14.2425C13.6375 11.6762 8.28375 11.2788 4.59125 12.6412C4.08 12.8137 3.5175 12.525 3.345 12.0137C3.1725 11.51 3.46125 10.9487 3.9725 10.7762C8.2225 9.20125 14.19 9.65625 18.2475 12.5925C18.7212 12.9437 18.9725 13.5362 18.6225 14.01ZM18.9088 10.6262C14.8225 7.67625 8.24125 7.515 4.38 8.96125C3.7975 9.16875 3.13375 8.8725 2.92625 8.29C2.71875 7.70625 3.01625 7.0425 3.59875 6.835C8.1 5.215 15.2788 5.4075 19.9488 9.015C20.4638 9.40875 20.5712 10.1662 20.1775 10.6812C19.7838 11.1963 19.0262 11.3037 18.9088 10.6262Z"/>
  </svg>
</div>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto py-6 sm:py-8">
        {activeTab === "tokenomics" && <div className="text-white">{renderTokenomicsContent()}</div>}
        {activeTab === "wallet" && <div className="text-white">{renderWalletContent()}</div>}
        {activeTab === "instagram" && <div className="text-white">{renderInstagramContent()}</div>}
        {activeTab === "facebook" && <div className="text-white">{renderFacebookContent()}</div>}
        {activeTab === "tiktok" && <div className="text-white">{renderTikTokContent()}</div>}
        {activeTab === "merch" && <div className="text-white">{renderMerchContent()}</div>}
        {activeTab === "live" && <div className="text-white">{renderLiveContent()}</div>}
        {activeTab === "streamer" && <div className="text-white">{renderStreamerContent()}</div>}
      </div>

      {/* Enhanced Modals with Artist Theme */}
      {/* Buy Modal */}
      <Modal isOpen={showBuyModal} onClose={() => setShowBuyModal(false)}>
        <div className="text-center bg-gradient-to-br from-purple-900/50 to-pink-900/50 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/30">
          <h2 className="text-xl sm:text-2xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            🛒 DFAITH & D.INVEST kaufen
          </h2>
          <div className="space-y-4">
            <Button
              onClick={() => {
                setShowBuyModal(false)
                setShowDinvestInfoModal(true)
              }}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
            >
              💎 D.INVEST mit € kaufen
            </Button>
            <Button
              onClick={() => {
                setShowBuyModal(false)
                setShowMaticBuyModal(true)
              }}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
            >
              🪙 DFAITH mit POL kaufen
            </Button>
          </div>
          <div className="mt-6">
            <Button
              onClick={() => setShowBuyModal(false)}
              className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold py-4 rounded-xl text-base sm:text-lg shadow-lg transform hover:scale-105 transition-all"
            >
              Schließen
            </Button>
          </div>
        </div>
      </Modal>

      {/* D.INVEST Info Modal */}
      <Modal isOpen={showDinvestInfoModal} onClose={() => setShowDinvestInfoModal(false)}>
        <div className="text-center bg-gradient-to-br from-blue-900/50 to-purple-900/50 backdrop-blur-lg rounded-2xl p-6 border border-blue-500/30">
          <h2 className="text-xl sm:text-2xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            💎 D.INVEST kaufen
          </h2>
          <div className="bg-blue-500/20 border border-blue-400/30 rounded-xl p-4 sm:p-6 mb-6 backdrop-blur-sm">
            <h3 className="font-bold text-blue-300 mb-3">💰 Preis: €5.00 pro D.INVEST</h3>
            <p className="text-blue-200 mb-4 text-sm sm:text-base">
              D.INVEST Tokens können direkt mit Euro gekauft werden und bieten stabile Staking-Rewards in DFAITH.
            </p>
            <div className="text-sm text-blue-300 space-y-2">
              <p>✅ Direkter Kauf mit Fiat-Währung</p>
              <p>✅ Staking für DFAITH Rewards</p>
              <p>✅ Unterstützung des Künstlers</p>
            </div>
          </div>

          <div className="space-y-4">
            <Button
              onClick={async () => {
                // Erst Wallet-Adresse kopieren
                if (isLoggedIn && walletAddress) {
                  try {
                    await navigator.clipboard.writeText(walletAddress)
                    alert(
                      `✅ Wallet-Adresse kopiert!\n\n${formatAddressFn(walletAddress)}\n\nWeiterleitung zu Stripe...`,
                    )
                  } catch (error) {
                    console.error("❌ Kopieren fehlgeschlagen:", error)
                    alert("⚠️ Kopieren fehlgeschlagen, aber Weiterleitung erfolgt trotzdem...")
                  }
                }

                // Dann Stripe öffnen
                setDinvestBuyClicked(true)
                window.open(process.env.NEXT_PUBLIC_STRIPE_DINVEST_LINK, "_blank")
              }}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-4 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
            >
              💳 Mit Stripe kaufen
            </Button>

            {dinvestBuyClicked && (
              <div className="bg-green-500/20 border border-green-400/30 rounded-xl p-4 backdrop-blur-sm">
                <p className="text-green-300 font-medium">✅ Stripe-Link geöffnet!</p>
                <p className="text-green-200 text-sm">
                  Nach dem Kauf werden deine D.INVEST Tokens automatisch an deine Wallet-Adresse gesendet.
                </p>
                <p className="text-green-400 text-xs mt-2">
                  Wallet: {isLoggedIn ? formatAddressFn(walletAddress) : "Bitte zuerst einloggen"}
                </p>
              </div>
            )}
          </div>

          <Button
            onClick={() => {
              setShowDinvestInfoModal(false)
              setDinvestBuyClicked(false)
            }}
            className="w-full mt-6 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
          >
            Schließen
          </Button>
        </div>
      </Modal>

      {/* MATIC Buy Modal */}
      <Modal
        isOpen={showMaticBuyModal}
        onClose={() => {
          setShowMaticBuyModal(false)
          setBuyAmount("")
          setBuyQuote(null)
          setIsMaticApproved(false)
        }}
      >
        <div className="text-center bg-gradient-to-br from-purple-900/50 to-pink-900/50 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/30">
          <h2 className="text-xl sm:text-2xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            DFAITH mit POL kaufen
          </h2>

          <div className="text-purple-300 font-bold mb-4">Balance: {maticBalance} POL</div>

          <div className="relative mb-6">
            <Input
              type="number"
              placeholder="z.B. 1.0 POL"
              className="text-center bg-white/10 backdrop-blur-sm border-2 border-purple-500/30 pr-16 sm:pr-20 text-sm sm:text-base text-white placeholder-purple-300 rounded-xl"
              style={{ fontSize: "16px", paddingRight: "80px" }}
              value={buyAmount}
              onChange={(e) => setBuyAmount(e.target.value)}
            />
            <button
              onClick={() => {
                const maxAmount = Math.max(0, Number.parseFloat(maticBalance) - 0.01)
                setBuyAmount(maxAmount.toFixed(4))
              }}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-purple-500/80 hover:bg-purple-600 text-white px-2 sm:px-3 py-1 text-xs rounded-lg font-medium transition-colors backdrop-blur-sm"
              style={{
                height: "calc(100% - 8px)",
                display: "flex",
                alignItems: "center",
                fontSize: "12px",
                fontWeight: "600",
              }}
            >
              MAX
            </button>
          </div>

          {/* Step Indicators */}
          <div className="flex justify-center mb-6">
            <div className="flex items-center space-x-2">
              <div
                className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white text-xs sm:text-sm font-bold ${buyQuote ? "bg-green-500" : "bg-gray-600"}`}
              >
                1
              </div>
              <div className="w-6 sm:w-8 h-1 bg-gray-600"></div>
              <div
                className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white text-xs sm:text-sm font-bold ${isMaticApproved ? "bg-green-500" : "bg-gray-600"}`}
              >
                2
              </div>
              <div className="w-6 sm:w-8 h-1 bg-gray-600"></div>
              <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white text-xs sm:text-sm font-bold bg-gray-600">
                3
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {/* Step 1: Get Quote */}
            <Button
              onClick={loadBuyQuote}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
              disabled={!buyAmount || buyQuote}
            >
              {buyQuote ? `✅ Quote geladen` : "🔄 1. Quote laden"}
            </Button>

            {/* Step 2: No Approve needed for MATIC */}
            {buyQuote && (
              <Button
                onClick={() => setIsMaticApproved(true)}
                className="w-full bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
                disabled={isMaticApproved}
              >
                {isMaticApproved ? "✅ POL bereit" : "🪙 2. POL bereit"}
              </Button>
            )}

            {/* Step 3: Execute Buy */}
            {buyQuote && isMaticApproved && (
              <Button
                onClick={executeBuySwapFn}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
              >
                ✅ 3. DFAITH kaufen
              </Button>
            )}
          </div>

          {/* Quote Display */}
          {buyQuote && (
            <div className="bg-purple-500/20 border border-purple-400/30 rounded-xl p-4 mt-6 backdrop-blur-sm">
              <div className="text-purple-300 font-bold mb-2">POL zu DFAITH Quote</div>
              <p className="text-white text-sm sm:text-base">
                <strong>Du erhältst:</strong> {(Number(buyQuote.dstAmount) / Math.pow(10, 18)).toFixed(4)} DFAITH
              </p>
              <p className="text-purple-200 text-xs sm:text-sm">
                <strong>Wechselkurs:</strong> 1 POL ={" "}
                {(Number(buyQuote.dstAmount) / Math.pow(10, 18) / Number.parseFloat(buyAmount)).toFixed(4)} DFAITH
              </p>
              <p className="text-purple-300 text-xs">
                <strong>Quelle:</strong> {buyQuote.priceSource}
              </p>
              {buyQuote.priceSource === "OpenOcean v3" ? (
                <p className="text-green-400 text-xs">🚀 Direkter nativer POL Swap</p>
              ) : (
                <p className="text-orange-400 text-xs">🔄 POL → WPOL → DFAITH</p>
              )}
            </div>
          )}

          <Button
            onClick={() => {
              setShowMaticBuyModal(false)
              setBuyAmount("")
              setBuyQuote(null)
              setIsMaticApproved(false)
            }}
            className="w-full mt-6 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
          >
            Schließen
          </Button>
        </div>
      </Modal>

      {/* Enhanced 3-Step Sell Modal */}
      <Modal
        isOpen={showSellModal}
        onClose={() => {
          setShowSellModal(false)
          setSellAmount("")
          setSellQuote(null)
          setIsApproved(false)
        }}
      >
        <div className="text-center bg-gradient-to-br from-red-900/50 to-rose-900/50 backdrop-blur-lg rounded-2xl p-6 border border-red-500/30">
          <h2 className="text-xl sm:text-2xl font-bold mb-4 bg-gradient-to-r from-red-400 to-rose-400 bg-clip-text text-transparent">
            DFAITH zu POL verkaufen
          </h2>
          <div className="text-orange-300 font-bold mb-4">Balance: {dfaithBalance} DFAITH</div>

          <div className="relative mb-6">
            <Input
              type="number"
              placeholder="z.B. 10 DFAITH"
              className="text-center bg-white/10 backdrop-blur-sm border-2 border-red-500/30 pr-16 sm:pr-20 text-sm sm:text-base text-white placeholder-red-300 rounded-xl"
              style={{ fontSize: "16px", paddingRight: "80px" }}
              value={sellAmount}
              onChange={(e) => setSellAmount(e.target.value)}
            />
            <button
              onClick={() => setSellAmount(dfaithBalance)}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-red-500/80 hover:bg-red-600 text-white px-2 sm:px-3 py-1 text-xs rounded-lg font-medium transition-colors backdrop-blur-sm"
              style={{
                height: "calc(100% - 8px)",
                display: "flex",
                alignItems: "center",
                fontSize: "12px",
                fontWeight: "600",
              }}
            >
              MAX
            </button>
          </div>

          {/* Step Indicators */}
          <div className="flex justify-center mb-6">
            <div className="flex items-center space-x-2">
              <div
                className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white text-xs sm:text-sm font-bold ${sellQuote ? "bg-green-500" : "bg-gray-600"}`}
              >
                1
              </div>
              <div className="w-6 sm:w-8 h-1 bg-gray-600"></div>
              <div
                className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white text-xs sm:text-sm font-bold ${isApproved ? "bg-green-500" : "bg-gray-600"}`}
              >
                2
              </div>
              <div className="w-6 sm:w-8 h-1 bg-gray-600"></div>
              <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-white text-xs sm:text-sm font-bold bg-gray-600">
                3
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {/* Step 1: Get Quote */}
            <Button
              onClick={loadSellQuote}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
              disabled={!sellAmount || sellQuote}
            >
              {sellQuote ? `✅ Quote geladen` : "🔄 1. Quote laden"}
            </Button>

            {/* Step 2: Approve DFAITH */}
            {sellQuote && (
              <Button
                onClick={approveDFaith}
                className="w-full bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
                disabled={isApproved}
              >
                {isApproved ? "✅ DFAITH freigegeben" : "🔓 2. DFAITH freigeben"}
              </Button>
            )}

            {/* Step 3: Execute Swap */}
            {sellQuote && isApproved && (
              <Button
                onClick={executeSwap}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
              >
                ✅ 3. Swap ausführen
              </Button>
            )}
          </div>

          {/* Quote Display */}
          {sellQuote && (
            <div className="bg-orange-500/20 border border-orange-400/30 rounded-xl p-4 mt-6 backdrop-blur-sm">
              <div className="text-orange-300 font-bold mb-2">DFAITH zu POL Quote</div>
              <p className="text-white text-sm sm:text-base">
                <strong>Du erhältst:</strong> {web3.utils.fromWei(sellQuote.dstAmount, "ether")} POL
              </p>
              <p className="text-orange-200 text-xs sm:text-sm">
                <strong>Wechselkurs:</strong> 1 DFAITH ={" "}
                {(
                  Number.parseFloat(web3.utils.fromWei(sellQuote.dstAmount, "ether")) / Number.parseFloat(sellAmount)
                ).toFixed(8)}{" "}
                POL
              </p>
              <p className="text-orange-300 text-xs">
                <strong>Quelle:</strong> {sellQuote.priceSource}
              </p>
              <p className="text-orange-400 text-xs">🔄 DFAITH → WPOL → POL</p>
            </div>
          )}

          <Button
            onClick={() => {
              setShowSellModal(false)
              setSellAmount("")
              setSellQuote(null)
              setIsApproved(false)
            }}
            className="w-full mt-6 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all text-sm sm:text-base"
          >
            Schließen
          </Button>
        </div>
      </Modal>

      {/* Send Modal */}
      <Modal isOpen={showSendModal} onClose={() => setShowSendModal(false)}>
        <div className="text-center bg-gradient-to-br from-blue-900/50 to-indigo-900/50 backdrop-blur-lg rounded-2xl p-6 border border-blue-500/30">
          <h2 className="text-xl sm:text-2xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
            Token senden
          </h2>
          <select
            value={sendToken}
            onChange={(e) => setSendToken(e.target.value)}
            className="w-full p-3 border border-blue-500/30 rounded-xl mb-4 text-center bg-white/10 backdrop-blur-sm text-white text-sm sm:text-base"
          >
            <option value="dfaith" className="bg-gray-800">
              DFAITH
            </option>
            <option value="matic" className="bg-gray-800">
              POL
            </option>
            <option value="dinvest" className="bg-gray-800">
              D.INVEST
            </option>
          </select>
          <div className="text-blue-300 font-bold mb-4">
            Balance:{" "}
            {sendToken === "dfaith"
              ? `${dfaithBalance} DFAITH`
              : sendToken === "matic"
                ? `${maticBalance} POL`
                : `${dinvestBalance} D.INVEST`}
          </div>
          <Input
            placeholder="Empfänger-Adresse (0x...)"
            className="mb-4 bg-white/10 backdrop-blur-sm border border-blue-500/30 text-white placeholder-blue-300 rounded-xl text-sm sm:text-base"
            value={sendAddress}
            onChange={(e) => setSendAddress(e.target.value)}
          />
          <div className="relative mb-4">
            <Input
              type="number"
              placeholder="Anzahl z.B. 5"
              className="pr-16 bg-white/10 backdrop-blur-sm border border-blue-500/30 text-white placeholder-blue-300 rounded-xl text-sm sm:text-base"
              value={sendAmount}
              onChange={(e) => setSendAmount(e.target.value)}
            />
            <Button
              onClick={setMaxSendAmount}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-blue-500/80 hover:bg-blue-600 text-white px-3 py-1 text-xs rounded-lg font-medium transition-colors backdrop-blur-sm"
            >
              Max
            </Button>
          </div>
          <Button
            onClick={executeSend}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white mb-4 py-3 rounded-xl font-bold text-sm sm:text-base shadow-lg transform hover:scale-105 transition-all"
          >
            ✅ Senden
          </Button>
          <Button
            onClick={() => setShowSendModal(false)}
            className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-6 py-2 rounded-xl text-sm sm:text-base shadow-lg transform hover:scale-105 transition-all"
          >
            Schließen
          </Button>
        </div>
      </Modal>

      {/* Transaction History Modal */}
      <Modal isOpen={showHistoryModal} onClose={() => setShowHistoryModal(false)}>
        <div className="text-center bg-gradient-to-br from-orange-900/50 to-amber-900/50 backdrop-blur-lg rounded-2xl p-6 border border-orange-500/30">
          <h2 className="text-xl sm:text-2xl font-bold mb-4 bg-gradient-to-r from-orange-400 to-amber-400 bg-clip-text text-transparent">
            📜 Transaktionshistorie
          </h2>
          <div className="max-h-96 overflow-y-auto">
            {transactions.length > 0 ? (
              <div className="space-y-3">
                {transactions.map((tx, index) => (
                  <div
                    key={index}
                    className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-left border border-white/20"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-bold text-orange-300">{tx.type}</span>
                      <span
                        className={`text-xs px-2 py-1 rounded-lg ${tx.status === "Success" ? "bg-green-500/30 text-green-300" : "bg-red-500/30 text-red-300"}`}
                      >
                        {tx.status}
                      </span>
                    </div>
                    <div className="text-sm text-gray-300 space-y-1">
                      <p>
                        <strong>Betrag:</strong> {tx.value} {tx.type}
                      </p>
                      <p>
                        <strong>Von:</strong> {tx.from.slice(0, 10)}...
                      </p>
                      <p>
                        <strong>An:</strong> {tx.to.slice(0, 10)}...
                      </p>
                      <p>
                        <strong>Zeit:</strong> {tx.timestamp}
                      </p>
                      <p>
                        <strong>Hash:</strong>{" "}
                        <a
                          href={`https://polygonscan.com/tx/${tx.hash}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-400 hover:underline"
                        >
                          {tx.hash.slice(0, 10)}...
                        </a>
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-300">Keine Transaktionen gefunden.</p>
            )}
          </div>
          <Button
            onClick={() => setShowHistoryModal(false)}
            className="mt-6 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-6 py-2 rounded-xl text-sm sm:text-base shadow-lg transform hover:scale-105 transition-all"
          >
            Schließen
          </Button>
        </div>
      </Modal>

      {/* Staking Modal */}
      <Modal isOpen={showStakingModal} onClose={() => setShowStakingModal(false)}>
        <div className="text-center bg-gradient-to-br from-blue-900/50 to-purple-900/50 backdrop-blur-lg rounded-2xl p-6 border border-blue-500/30">
          <h2 className="text-xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            🔒 D.INVEST Staking
          </h2>

          {/* Kompakte Balance Anzeige */}
          <div className="grid grid-cols-3 gap-2 mb-4 text-xs">
            <div className="bg-blue-500/20 backdrop-blur-sm rounded-xl p-2 border border-blue-400/30">
              <p className="text-blue-300 font-medium">💎 Verfügbar</p>
              <p className="text-blue-200 font-bold">{dinvestBalance}</p>
            </div>
            <div className="bg-green-500/20 backdrop-blur-sm rounded-xl p-2 border border-green-400/30">
              <p className="text-green-300 font-medium">🔒 Gestaked</p>
              <p className="text-green-200 font-bold">{stakedDinvestAmount}</p>
            </div>
            <div className="bg-yellow-500/20 backdrop-blur-sm rounded-xl p-2 border border-yellow-400/30">
              <p className="text-yellow-300 font-medium">🎁 Rewards</p>
              <p className="text-yellow-200 font-bold text-xs">{formatRewards(earnedDfaithRewards)}</p>
            </div>
          </div>

          {/* Kompakte Staking Aktionen */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            {/* Stake */}
            <div className="bg-green-500/20 border border-green-400/30 rounded-xl p-3 backdrop-blur-sm">
              <h3 className="font-bold text-green-300 mb-2 text-sm">🔒 Staken</h3>
              <div className="relative mb-2">
                <Input
                  type="number"
                  placeholder="Anzahl"
                  className="text-center bg-white/10 backdrop-blur-sm pr-10 text-white text-xs h-8 border border-green-400/30 rounded-lg"
                  value={stakeAmount}
                  onChange={(e) => setStakeAmount(e.target.value)}
                />
                <Button
                  onClick={setMaxStakeAmount}
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 bg-green-500/80 hover:bg-green-600 text-white px-1 py-0 text-xs rounded h-6 backdrop-blur-sm"
                >
                  Max
                </Button>
              </div>
              <Button
                onClick={executeStake}
                className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-1 rounded-lg text-xs h-7 shadow-lg transform hover:scale-105 transition-all"
                disabled={!stakeAmount || Number.parseFloat(stakeAmount) <= 0}
              >
                Staken
              </Button>
            </div>

            {/* Unstake */}
            <div className="bg-red-500/20 border border-red-400/30 rounded-xl p-3 backdrop-blur-sm">
              <h3 className="font-bold text-red-300 mb-2 text-sm">🔓 Unstaken</h3>
              <div className="relative mb-2">
                <Input
                  type="number"
                  placeholder="Anzahl"
                  className="text-center bg-white/10 backdrop-blur-sm pr-10 text-white text-xs h-8 border border-red-400/30 rounded-lg"
                  value={unstakeAmount}
                  onChange={(e) => setUnstakeAmount(e.target.value)}
                  disabled={Number.parseFloat(stakedDinvestAmount) <= 0}
                />
                <Button
                  onClick={setMaxUnstakeAmount}
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 bg-red-500/80 hover:bg-red-600 text-white px-1 py-0 text-xs rounded h-6 backdrop-blur-sm"
                  disabled={Number.parseFloat(stakedDinvestAmount) <= 0}
                >
                  Max
                </Button>
              </div>
              <Button
                onClick={executeUnstake}
                className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold py-1 rounded-lg text-xs h-7 shadow-lg transform hover:scale-105 transition-all"
                disabled={
                  !unstakeAmount || Number.parseFloat(unstakeAmount) <= 0 || Number.parseFloat(stakedDinvestAmount) <= 0
                }
              >
                Unstaken
              </Button>
            </div>
          </div>

          {/* Rewards Claim - immer sichtbar */}
          {Number.parseFloat(stakedDinvestAmount) > 0 && (
            <div className="bg-yellow-500/20 border border-yellow-400/30 rounded-xl p-3 mb-4 backdrop-blur-sm">
              <div className="text-yellow-300 font-bold mb-2 text-sm">🎁 Verfügbare Rewards</div>
              <div
                className="text-white text-lg font-mono mb-3 break-all cursor-pointer hover:bg-yellow-500/10 rounded p-1 transition-colors"
                onClick={() => setShowFullRewards(!showFullRewards)}
                title="Klicken um vollständige Zahl anzuzeigen"
              >
                {showFullRewards ? earnedDfaithRewards : formatRewards(earnedDfaithRewards)} DFAITH
                <span className="text-yellow-400 text-xs ml-2">{showFullRewards ? "🔽" : "🔼"}</span>
              </div>
              <Button
                onClick={claimRewards}
                className={`w-full bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-600 hover:to-amber-700 text-white font-bold py-2 rounded-xl text-sm shadow-lg transform hover:scale-105 transition-all ${
                  Number.parseFloat(earnedDfaithRewards) > 0.0001 ? "animate-pulse" : ""
                }`}
                style={
                  Number.parseFloat(earnedDfaithRewards) > 0.0001
                    ? {
                        boxShadow: "0 0 20px rgba(251, 191, 36, 0.6), 0 0 40px rgba(251, 191, 36, 0.4)",
                      }
                    : {}
                }
                disabled={Number.parseFloat(earnedDfaithRewards) <= 0.0001}
              >
                🎁 Jetzt claimen
              </Button>
            </div>
          )}

          {/* Kompakte Info */}
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 mb-4 border border-white/20">
            <div className="text-xs text-gray-300 space-y-1">
              <p>• 0.1 DFAITH pro D.INVEST pro Woche</p>
              <p>• Jederzeit unstaken möglich</p>
              <p>• Claim ab 0.0001 DFAITH</p>
            </div>
          </div>

          <Button
            onClick={() => setShowStakingModal(false)}
            className="w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold py-2 rounded-xl text-sm shadow-lg transform hover:scale-105 transition-all"
          >
            Schließen
          </Button>
        </div>
      </Modal>
    </div>
  )
}
