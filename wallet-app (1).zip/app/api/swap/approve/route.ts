import { type NextRequest, NextResponse } from "next/server"

const DFAITH_CONTRACT = "0xEE27258975a2DA946CD5025134D70E5E24F6789F"

// Common DEX Router addresses on Polygon
const DEX_ROUTERS = {
  ONEINCH: "0x1111111254EEB25477B68fb85Ed929f73A960582", // 1inch v5 Router
  OPENOCEAN: "0x6352a56caadC4F1E25CD6c75970Fa768A3304e64", // OpenOcean Router
  PARASWAP: "0xDEF171Fe48CF0115B1d80b88dc8eAB59176FEe57", // ParaSwap Router
  UNISWAP: "0xE592427A0AEce92De3Edee1F18E0157C05861564", // Uniswap V3 Router
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const tokenAddress = searchParams.get("tokenAddress")
    const amount = searchParams.get("amount")

    console.log("🔓 Approve Request:", { tokenAddress, amount })

    if (!tokenAddress || !amount) {
      return NextResponse.json({ error: "Missing required parameters: tokenAddress, amount" }, { status: 400 })
    }

    // Validate D.Faith token address
    if (tokenAddress.toLowerCase() !== DFAITH_CONTRACT.toLowerCase()) {
      return NextResponse.json(
        {
          error: "Invalid token address",
          expected: DFAITH_CONTRACT,
          received: tokenAddress,
        },
        { status: 400 },
      )
    }

    // Validate amount
    const numericAmount = Number(amount)
    if (isNaN(numericAmount) || numericAmount <= 0) {
      return NextResponse.json({ error: "Invalid amount: must be a positive number" }, { status: 400 })
    }

    console.log("✅ Approve parameters validated, trying multiple strategies...")

    // Strategy 1: Try OpenOcean Allowance API
    try {
      console.log("🥇 Trying OpenOcean Allowance API...")
      const openOceanApproval = await tryOpenOceanAllowance(tokenAddress, amount)
      if (openOceanApproval) {
        console.log("✅ OpenOcean Allowance successful!")
        return NextResponse.json(openOceanApproval)
      }
    } catch (error) {
      console.log("❌ OpenOcean Allowance failed:", error.message)
    }

    // Strategy 2: Try 1inch Allowance API
    try {
      console.log("🥈 Trying 1inch Allowance API...")
      const oneinchApproval = await try1inchAllowance(tokenAddress, amount)
      if (oneinchApproval) {
        console.log("✅ 1inch Allowance successful!")
        return NextResponse.json(oneinchApproval)
      }
    } catch (error) {
      console.log("❌ 1inch Allowance failed:", error.message)
    }

    // Strategy 3: Direct ERC20 Approve (most reliable fallback)
    console.log("🥉 Using direct ERC20 approve fallback...")
    const directApproval = createDirectApproval(tokenAddress, amount)
    console.log("✅ Direct ERC20 Approval created!")
    return NextResponse.json(directApproval)
  } catch (error) {
    console.error("❌ Approve API Critical Error:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        details: error.message,
        suggestion: "Try again or use direct approval",
      },
      { status: 500 },
    )
  }
}

// OpenOcean Allowance API
async function tryOpenOceanAllowance(tokenAddress: string, amount: string) {
  const allowanceUrl = "https://open-api.openocean.finance/v4/137/allowance"
  const params = new URLSearchParams({
    inTokenAddress: tokenAddress,
  })

  console.log("📞 OpenOcean Allowance URL:", `${allowanceUrl}?${params.toString()}`)

  const response = await fetch(`${allowanceUrl}?${params.toString()}`, {
    headers: {
      accept: "application/json",
      "User-Agent": "D.Faith-Wallet/1.0",
    },
    timeout: 10000,
  })

  const responseText = await response.text()
  console.log("📋 OpenOcean Allowance Response:", {
    status: response.status,
    bodyLength: responseText.length,
    bodyPreview: responseText.substring(0, 300),
  })

  if (!response.ok) {
    throw new Error(`OpenOcean Allowance API error: ${response.status} - ${responseText}`)
  }

  const allowanceData = JSON.parse(responseText)

  if (!allowanceData.spender) {
    throw new Error("OpenOcean: Missing spender address in response")
  }

  return createApprovalTransaction(tokenAddress, amount, allowanceData.spender, "OpenOcean")
}

// 1inch Allowance API
async function try1inchAllowance(tokenAddress: string, amount: string) {
  const allowanceUrl = `https://api.1inch.dev/swap/v6.0/137/approve/spender`

  console.log("📞 1inch Allowance URL:", allowanceUrl)

  const response = await fetch(allowanceUrl, {
    headers: {
      Authorization: `Bearer gkpYwoz5c9Uzh3o01jQXiAd6GwQSzBbo`,
      accept: "application/json",
    },
    timeout: 10000,
  })

  const responseText = await response.text()
  console.log("📋 1inch Allowance Response:", {
    status: response.status,
    bodyLength: responseText.length,
    bodyPreview: responseText.substring(0, 300),
  })

  if (!response.ok) {
    throw new Error(`1inch Allowance API error: ${response.status} - ${responseText}`)
  }

  const allowanceData = JSON.parse(responseText)

  if (!allowanceData.address) {
    throw new Error("1inch: Missing spender address in response")
  }

  return createApprovalTransaction(tokenAddress, amount, allowanceData.address, "1inch")
}

// Direct ERC20 Approve (most reliable fallback)
function createDirectApproval(tokenAddress: string, amount: string) {
  // Use OpenOcean router as default spender (most commonly used)
  const spenderAddress = DEX_ROUTERS.OPENOCEAN

  return createApprovalTransaction(tokenAddress, amount, spenderAddress, "Direct-ERC20")
}

// Create ERC20 approval transaction data
function createApprovalTransaction(tokenAddress: string, amount: string, spenderAddress: string, source: string) {
  console.log("🔧 Creating approval transaction:", {
    tokenAddress,
    amount,
    spenderAddress,
    source,
  })

  // ERC20 approve function signature: approve(address spender, uint256 amount)
  const approveSignature = "0x095ea7b3" // approve(address,uint256)

  // Remove 0x prefix and pad to 32 bytes (64 hex chars)
  const paddedSpender = spenderAddress.slice(2).toLowerCase().padStart(64, "0")

  // Convert amount to hex and pad to 32 bytes
  const amountBigInt = BigInt(amount)
  const paddedAmount = amountBigInt.toString(16).padStart(64, "0")

  // Combine signature + spender + amount
  const data = approveSignature + paddedSpender + paddedAmount

  const approvalTx = {
    to: tokenAddress,
    data: data,
    gasLimit: "100000", // Standard gas limit for ERC20 approve
    value: "0",
    spender: spenderAddress,
    source: source,
    amount: amount,
    isDirectApproval: source === "Direct-ERC20",
  }

  console.log("✅ Approval transaction created:", {
    to: approvalTx.to,
    dataLength: approvalTx.data.length,
    spender: approvalTx.spender,
    source: approvalTx.source,
    gasLimit: approvalTx.gasLimit,
  })

  return approvalTx
}
