import { type NextRequest, NextResponse } from "next/server"

const ONEINCH_API_KEY = "gkpYwoz5c9Uzh3o01jQXiAd6GwQSzBbo"
const DFAITH_CONTRACT = "0xEE27258975a2DA946CD5025134D70E5E24F6789F"
const WMATIC_CONTRACT = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const src = searchParams.get("src")
    const dst = searchParams.get("dst")
    const amount = searchParams.get("amount")
    const from = searchParams.get("from")
    const slippage = searchParams.get("slippage") || "1"

    if (!src || !dst || !amount || !from) {
      return NextResponse.json({ error: "Missing required parameters: src, dst, amount, from" }, { status: 400 })
    }

    console.log("🔄 1inch Swap Execute Request:", { src, dst, amount, from, slippage })

    // Validate token addresses
    const validTokens = [DFAITH_CONTRACT.toLowerCase(), WMATIC_CONTRACT.toLowerCase()]
    if (!validTokens.includes(src.toLowerCase()) || !validTokens.includes(dst.toLowerCase())) {
      return NextResponse.json(
        {
          error: "Invalid token addresses",
          validTokens: [DFAITH_CONTRACT, WMATIC_CONTRACT],
          received: { src, dst },
        },
        { status: 400 },
      )
    }

    // 1inch Swap API v6 - direkt mit TX-Daten
    const swapUrl = `https://api.1inch.dev/swap/v6.0/137/swap?src=${src}&dst=${dst}&amount=${amount}&from=${from}&slippage=${slippage}&includeTokensInfo=true&includeProtocols=true&includeGas=true`

    console.log("📞 1inch Swap URL:", swapUrl)

    const response = await fetch(swapUrl, {
      headers: {
        Authorization: `Bearer ${ONEINCH_API_KEY}`,
        accept: "application/json",
      },
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("❌ 1inch Swap API error:", response.status, errorText)

      // Fallback für bessere Fehlermeldungen
      if (response.status === 400) {
        return NextResponse.json(
          {
            error: "1inch API Fehler - möglicherweise nicht genügend Liquidität",
            details: errorText,
            suggestion: "Versuche einen kleineren Betrag oder warte einen Moment",
          },
          { status: 400 },
        )
      }

      return NextResponse.json(
        { error: `1inch API error: ${response.status}`, details: errorText },
        { status: response.status },
      )
    }

    const swapData = await response.json()

    console.log("✅ 1inch Swap Response:", {
      srcToken: swapData.srcToken?.symbol,
      dstToken: swapData.dstToken?.symbol,
      dstAmount: swapData.dstAmount,
      hasTransaction: !!swapData.tx,
      txTo: swapData.tx?.to,
      protocols: swapData.protocols?.length || 0,
    })

    // Ensure transaction data is present
    if (!swapData.tx) {
      return NextResponse.json(
        {
          error: "Keine Transaktionsdaten von 1inch erhalten",
          suggestion: "Versuche es mit einem anderen Betrag",
        },
        { status: 400 },
      )
    }

    // Return complete swap data with transaction
    return NextResponse.json({
      srcToken: swapData.srcToken,
      dstToken: swapData.dstToken,
      dstAmount: swapData.dstAmount,
      estimatedGas: swapData.estimatedGas,
      protocols: swapData.protocols,
      tx: swapData.tx,
      priceSource: "1inch",
      isRealQuote: true,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("❌ Swap Execute API error:", error)
    return NextResponse.json({ error: "Internal server error", details: error.message }, { status: 500 })
  }
}
