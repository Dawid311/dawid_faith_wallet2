import { type NextRequest, NextResponse } from "next/server"

const DFAITH_CONTRACT = "0xEE27258975a2DA946CD5025134D70E5E24F6789F"
const WMATIC_CONTRACT = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"
const ONEINCH_API_KEY = "gkpYwoz5c9Uzh3o01jQXiAd6GwQSzBbo"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const amount = searchParams.get("amount") // MATIC amount in wei
    const account = searchParams.get("account")

    console.log("🔍 Buy Quote Request Parameters:", { amount, account })

    if (!amount) {
      return NextResponse.json({ error: "Missing required parameter: amount" }, { status: 400 })
    }

    // Validate amount
    const numericAmount = Number(amount)
    if (isNaN(numericAmount) || numericAmount <= 0) {
      return NextResponse.json({ error: "Invalid amount: must be a positive number" }, { status: 400 })
    }

    console.log("✅ Buy quote parameters validated, trying multiple DEX APIs...")

    // Strategy 1: Try 1inch API first (MATIC to D.Faith)
    try {
      console.log("🥇 Trying 1inch API for MATIC to DFAITH...")
      const oneinchQuote = await try1inchBuyQuote(amount, account)
      if (oneinchQuote) {
        console.log("✅ 1inch Buy Quote successful!")
        return NextResponse.json(oneinchQuote)
      }
    } catch (error) {
      console.log("❌ 1inch buy quote failed:", error.message)
    }

    // Strategy 2: Try OpenOcean API
    try {
      console.log("🥈 Trying OpenOcean API for MATIC to DFAITH...")
      const openOceanQuote = await tryOpenOceanBuyQuote(amount, account)
      if (openOceanQuote) {
        console.log("✅ OpenOcean Buy Quote successful!")
        return NextResponse.json(openOceanQuote)
      }
    } catch (error) {
      console.log("❌ OpenOcean buy quote failed:", error.message)
    }

    // Strategy 3: Try ParaSwap API
    try {
      console.log("🥉 Trying ParaSwap API for MATIC to DFAITH...")
      const paraSwapQuote = await tryParaSwapBuyQuote(amount, account)
      if (paraSwapQuote) {
        console.log("✅ ParaSwap Buy Quote successful!")
        return NextResponse.json(paraSwapQuote)
      }
    } catch (error) {
      console.log("❌ ParaSwap buy quote failed:", error.message)
    }

    // Strategy 4: Fallback with realistic mock data
    console.log("🔄 All APIs failed, using intelligent fallback...")
    const fallbackQuote = createBuyFallbackQuote(amount, account)
    return NextResponse.json(fallbackQuote)
  } catch (error) {
    console.error("❌ Buy Quote API Critical Error:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        details: error.message,
        suggestion: "Try again in a few moments",
      },
      { status: 500 },
    )
  }
}

// 1inch API Implementation for MATIC to D.Faith - MIT TX-DATEN
async function try1inchBuyQuote(amount: string, account?: string) {
  // Immer mit account parameter für TX-Daten
  if (!account || !account.startsWith("0x")) {
    throw new Error("Account address required for transaction data")
  }

  const swapUrl = `https://api.1inch.dev/swap/v6.0/137/swap?src=${WMATIC_CONTRACT}&dst=${DFAITH_CONTRACT}&amount=${amount}&from=${account}&slippage=1&includeTokensInfo=true&includeProtocols=true&includeGas=true`

  console.log("📞 1inch Buy Swap URL:", swapUrl)

  const response = await fetch(swapUrl, {
    headers: {
      Authorization: `Bearer ${ONEINCH_API_KEY}`,
      accept: "application/json",
    },
    timeout: 10000,
  })

  const responseText = await response.text()
  console.log("📋 1inch Buy Response:", {
    status: response.status,
    bodyLength: responseText.length,
    bodyPreview: responseText.substring(0, 300),
  })

  if (!response.ok) {
    throw new Error(`1inch API error: ${response.status} - ${responseText}`)
  }

  const swapData = JSON.parse(responseText)

  return {
    srcToken: {
      symbol: swapData.srcToken?.symbol || "WMATIC",
      address: WMATIC_CONTRACT,
      decimals: swapData.srcToken?.decimals || 18,
    },
    dstToken: {
      symbol: swapData.dstToken?.symbol || "DFAITH",
      address: DFAITH_CONTRACT,
      decimals: swapData.dstToken?.decimals || 18,
    },
    dstAmount: swapData.dstAmount.toString(),
    estimatedGas: swapData.estimatedGas?.toString() || "300000",
    protocols: swapData.protocols || [
      {
        name: "1inch",
        part: 100,
        fromTokenAddress: WMATIC_CONTRACT,
        toTokenAddress: DFAITH_CONTRACT,
      },
    ],
    tx: swapData.tx, // TX-Daten direkt von 1inch
    isRealQuote: true,
    priceSource: "1inch",
    timestamp: new Date().toISOString(),
  }
}

// OpenOcean API Implementation for MATIC to D.Faith - MIT TX-DATEN
async function tryOpenOceanBuyQuote(amount: string, account?: string) {
  if (!account || !account.startsWith("0x")) {
    throw new Error("Account address required for transaction data")
  }

  const baseUrl = "https://open-api.openocean.finance/v4/137/swap"
  const params = new URLSearchParams({
    inTokenAddress: WMATIC_CONTRACT.toLowerCase(),
    outTokenAddress: DFAITH_CONTRACT.toLowerCase(),
    amount: amount.toString(),
    gasPrice: "30000000000",
    slippage: "1",
    account: account.toLowerCase(),
  })

  const quoteUrl = `${baseUrl}?${params.toString()}`
  console.log("📞 OpenOcean Buy Quote URL:", quoteUrl)

  const response = await fetch(quoteUrl, {
    headers: {
      accept: "application/json",
      "User-Agent": "D.Faith-Wallet/1.0",
    },
    timeout: 15000,
  })

  const responseText = await response.text()
  console.log("📋 OpenOcean Buy Response:", {
    status: response.status,
    bodyLength: responseText.length,
    bodyPreview: responseText.substring(0, 300),
  })

  if (!response.ok) {
    throw new Error(`OpenOcean API error: ${response.status} - ${responseText}`)
  }

  const quoteData = JSON.parse(responseText)

  if (quoteData.code && quoteData.code !== 200) {
    throw new Error(`OpenOcean Error: ${quoteData.code} - ${quoteData.message}`)
  }

  if (!quoteData.outAmount) {
    throw new Error("OpenOcean: Missing outAmount in response")
  }

  return {
    srcToken: {
      symbol: quoteData.inToken?.symbol || "WMATIC",
      address: WMATIC_CONTRACT,
      decimals: quoteData.inToken?.decimals || 18,
    },
    dstToken: {
      symbol: quoteData.outToken?.symbol || "DFAITH",
      address: DFAITH_CONTRACT,
      decimals: quoteData.outToken?.decimals || 18,
    },
    dstAmount: quoteData.outAmount.toString(),
    estimatedGas: quoteData.estimatedGas?.toString() || "300000",
    protocols: [
      {
        name: "OpenOcean",
        part: 100,
        fromTokenAddress: WMATIC_CONTRACT,
        toTokenAddress: DFAITH_CONTRACT,
      },
    ],
    tx: {
      to: quoteData.to,
      data: quoteData.data,
      value: amount, // MATIC value für Buy
      gasLimit: quoteData.estimatedGas?.toString() || "300000",
    },
    isRealQuote: true,
    priceSource: "OpenOcean",
    timestamp: new Date().toISOString(),
  }
}

// ParaSwap API Implementation for MATIC to D.Faith
async function tryParaSwapBuyQuote(amount: string, account?: string) {
  const priceUrl = `https://apiv5.paraswap.io/prices?srcToken=${WMATIC_CONTRACT}&destToken=${DFAITH_CONTRACT}&amount=${amount}&srcDecimals=18&destDecimals=4&side=SELL&network=137`

  console.log("📞 ParaSwap Buy Price URL:", priceUrl)

  const response = await fetch(priceUrl, {
    headers: {
      accept: "application/json",
    },
    timeout: 10000,
  })

  const responseText = await response.text()
  console.log("📋 ParaSwap Buy Response:", {
    status: response.status,
    bodyLength: responseText.length,
    bodyPreview: responseText.substring(0, 300),
  })

  if (!response.ok) {
    throw new Error(`ParaSwap API error: ${response.status} - ${responseText}`)
  }

  const priceData = JSON.parse(responseText)

  if (!priceData.priceRoute || !priceData.priceRoute.destAmount) {
    throw new Error("ParaSwap: Invalid price response")
  }

  // Get transaction data if account provided
  let txData = null
  if (account && account.startsWith("0x")) {
    try {
      const txUrl = "https://apiv5.paraswap.io/transactions/137"
      const txResponse = await fetch(txUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          srcToken: WMATIC_CONTRACT,
          destToken: DFAITH_CONTRACT,
          srcAmount: amount,
          destAmount: priceData.priceRoute.destAmount,
          priceRoute: priceData.priceRoute,
          userAddress: account,
          slippage: 100, // 1%
        }),
        timeout: 10000,
      })

      if (txResponse.ok) {
        const txResponseData = await txResponse.json()
        txData = {
          to: txResponseData.to,
          data: txResponseData.data,
          value: txResponseData.value || amount,
          gasLimit: "300000",
        }
      }
    } catch (txError) {
      console.log("⚠️ ParaSwap transaction data failed, quote only:", txError.message)
    }
  }

  return {
    srcToken: {
      symbol: "WMATIC",
      address: WMATIC_CONTRACT,
      decimals: 18,
    },
    dstToken: {
      symbol: "DFAITH",
      address: DFAITH_CONTRACT,
      decimals: 18,
    },
    dstAmount: priceData.priceRoute.destAmount,
    estimatedGas: priceData.priceRoute.gasCost || "300000",
    protocols: [
      {
        name: "ParaSwap",
        part: 100,
        fromTokenAddress: WMATIC_CONTRACT,
        toTokenAddress: DFAITH_CONTRACT,
      },
    ],
    tx: txData,
    isRealQuote: true,
    priceSource: "ParaSwap",
    timestamp: new Date().toISOString(),
  }
}

// Intelligent Fallback for MATIC to D.Faith - MIT TX-DATEN
function createBuyFallbackQuote(amount: string, account?: string) {
  console.log("🔄 Creating intelligent buy fallback quote...")

  // Realistic MATIC to D.Faith rate
  const maticAmount = Number(amount) / Math.pow(10, 18) // Convert from wei to MATIC
  const estimatedDFaithRate = 10000 // 1 MATIC ≈ 10000 D.Faith (realistic for small tokens)
  const dfaithAmount = maticAmount * estimatedDFaithRate
  const dfaithAmountWei = Math.floor(dfaithAmount * Math.pow(10, 18)).toString()

  return {
    srcToken: {
      symbol: "WMATIC",
      address: WMATIC_CONTRACT,
      decimals: 18,
    },
    dstToken: {
      symbol: "DFAITH",
      address: DFAITH_CONTRACT,
      decimals: 18,
    },
    dstAmount: dfaithAmountWei,
    estimatedGas: "250000",
    protocols: [
      {
        name: "Fallback-Estimator",
        part: 100,
        fromTokenAddress: WMATIC_CONTRACT,
        toTokenAddress: DFAITH_CONTRACT,
      },
    ],
    tx: account
      ? {
          to: "0x6352a56caadC4F1E25CD6c75970Fa768A3304e64", // OpenOcean Router
          data: "0x", // Placeholder
          value: amount, // MATIC amount
          gasLimit: "250000",
        }
      : undefined,
    isRealQuote: false,
    isFallback: true,
    priceSource: "Fallback-Estimator",
    timestamp: new Date().toISOString(),
    warning: "Dies ist eine geschätzte Quote. Echte DEX APIs sind momentan nicht verfügbar.",
  }
}
