import { type NextRequest, NextResponse } from "next/server"

const DFAITH_CONTRACT = "0xEE27258975a2DA946CD5025134D70E5E24F6789F"
const WMATIC_CONTRACT = "0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270"
const ONEINCH_API_KEY = "gkpYwoz5c9Uzh3o01jQXiAd6GwQSzBbo"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const src = searchParams.get("src")
    const dst = searchParams.get("dst")
    const amount = searchParams.get("amount")
    const account = searchParams.get("account")

    console.log("🔍 Quote Request Parameters:", { src, dst, amount, account })

    if (!src || !dst || !amount) {
      return NextResponse.json({ error: "Missing required parameters: src, dst, amount" }, { status: 400 })
    }

    // Validate and format amount
    const numericAmount = Number(amount)
    if (isNaN(numericAmount) || numericAmount <= 0) {
      return NextResponse.json({ error: "Invalid amount: must be a positive number" }, { status: 400 })
    }

    // Validate D.Faith address
    if (src.toLowerCase() !== DFAITH_CONTRACT.toLowerCase()) {
      return NextResponse.json(
        {
          error: "Invalid source token address",
          expected: DFAITH_CONTRACT,
          received: src,
        },
        { status: 400 },
      )
    }

    console.log("✅ Parameters validated, trying multiple DEX APIs...")

    // Strategy 1: Try 1inch API first (most reliable)
    try {
      console.log("🥇 Trying 1inch API...")
      const oneinchQuote = await try1inchQuote(src, dst, amount, account)
      if (oneinchQuote) {
        console.log("✅ 1inch Quote successful!")
        return NextResponse.json(oneinchQuote)
      }
    } catch (error) {
      console.log("❌ 1inch failed:", error.message)
    }

    // Strategy 2: Try OpenOcean API
    try {
      console.log("🥈 Trying OpenOcean API...")
      const openOceanQuote = await tryOpenOceanQuote(src, dst, amount, account)
      if (openOceanQuote) {
        console.log("✅ OpenOcean Quote successful!")
        return NextResponse.json(openOceanQuote)
      }
    } catch (error) {
      console.log("❌ OpenOcean failed:", error.message)
    }

    // Strategy 3: Try ParaSwap API
    try {
      console.log("🥉 Trying ParaSwap API...")
      const paraSwapQuote = await tryParaSwapQuote(src, dst, amount, account)
      if (paraSwapQuote) {
        console.log("✅ ParaSwap Quote successful!")
        return NextResponse.json(paraSwapQuote)
      }
    } catch (error) {
      console.log("❌ ParaSwap failed:", error.message)
    }

    // Strategy 4: Fallback with realistic mock data
    console.log("🔄 All APIs failed, using intelligent fallback...")
    const fallbackQuote = createFallbackQuote(src, dst, amount, account)
    return NextResponse.json(fallbackQuote)
  } catch (error) {
    console.error("❌ Quote API Critical Error:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        details: error.message,
        suggestion: "Try again in a few moments",
      },
      { status: 500 },
    )
  }
}

// 1inch API Implementation
async function try1inchQuote(src: string, dst: string, amount: string, account?: string) {
  const quoteUrl = `https://api.1inch.dev/swap/v6.0/137/quote?src=${src}&dst=${dst}&amount=${amount}&includeTokensInfo=true&includeProtocols=true&includeGas=true`

  console.log("📞 1inch Quote URL:", quoteUrl)

  const response = await fetch(quoteUrl, {
    headers: {
      Authorization: `Bearer ${ONEINCH_API_KEY}`,
      accept: "application/json",
    },
    timeout: 10000,
  })

  const responseText = await response.text()
  console.log("📋 1inch Response:", {
    status: response.status,
    bodyLength: responseText.length,
    bodyPreview: responseText.substring(0, 300),
  })

  if (!response.ok) {
    throw new Error(`1inch API error: ${response.status} - ${responseText}`)
  }

  const quoteData = JSON.parse(responseText)

  // Get transaction data if account provided
  let txData = null
  if (account && account.startsWith("0x")) {
    try {
      const swapUrl = `https://api.1inch.dev/swap/v6.0/137/swap?src=${src}&dst=${dst}&amount=${amount}&from=${account}&slippage=1&includeTokensInfo=true&includeProtocols=true&includeGas=true`

      const swapResponse = await fetch(swapUrl, {
        headers: {
          Authorization: `Bearer ${ONEINCH_API_KEY}`,
          accept: "application/json",
        },
        timeout: 10000,
      })

      if (swapResponse.ok) {
        const swapData = await swapResponse.json()
        txData = swapData.tx
      }
    } catch (swapError) {
      console.log("⚠️ 1inch swap data failed, quote only:", swapError.message)
    }
  }

  return {
    srcToken: {
      symbol: "DFAITH",
      address: src,
      decimals: quoteData.srcToken?.decimals || 18,
    },
    dstToken: {
      symbol: quoteData.dstToken?.symbol || "WMATIC",
      address: dst,
      decimals: quoteData.dstToken?.decimals || 18,
    },
    dstAmount: quoteData.dstAmount.toString(),
    estimatedGas: quoteData.estimatedGas?.toString() || "300000",
    protocols: quoteData.protocols || [
      {
        name: "1inch",
        part: 100,
        fromTokenAddress: src,
        toTokenAddress: dst,
      },
    ],
    tx: txData,
    isRealQuote: true,
    priceSource: "1inch",
    timestamp: new Date().toISOString(),
  }
}

// OpenOcean API Implementation (improved)
async function tryOpenOceanQuote(src: string, dst: string, amount: string, account?: string) {
  const baseUrl = "https://open-api.openocean.finance/v4/137/swap"
  const params = new URLSearchParams({
    inTokenAddress: src.toLowerCase(),
    outTokenAddress: dst.toLowerCase(),
    amountDecimals: amount.toString(),
    gasPriceDecimals: "30000000000",
    slippage: "1",
  })

  if (account && account.startsWith("0x")) {
    params.append("account", account.toLowerCase())
  }

  const quoteUrl = `${baseUrl}?${params.toString()}`
  console.log("📞 OpenOcean Quote URL:", quoteUrl)

  const response = await fetch(quoteUrl, {
    headers: {
      accept: "application/json",
      "User-Agent": "D.Faith-Wallet/1.0",
    },
    timeout: 15000,
  })

  const responseText = await response.text()
  console.log("📋 OpenOcean Response:", {
    status: response.status,
    bodyLength: responseText.length,
    bodyPreview: responseText.substring(0, 300),
  })

  if (!response.ok) {
    throw new Error(`OpenOcean API error: ${response.status} - ${responseText}`)
  }

  const quoteData = JSON.parse(responseText)

  if (quoteData.code && quoteData.code !== 200) {
    throw new Error(`OpenOcean Error: ${quoteData.code} - ${quoteData.message}`)
  }

  if (!quoteData.outAmount) {
    throw new Error("OpenOcean: Missing outAmount in response")
  }

  return {
    srcToken: {
      symbol: "DFAITH",
      address: src,
      decimals: quoteData.inToken?.decimals || 18,
    },
    dstToken: {
      symbol: quoteData.outToken?.symbol || "WMATIC",
      address: dst,
      decimals: quoteData.outToken?.decimals || 18,
    },
    dstAmount: quoteData.outAmount.toString(),
    estimatedGas: quoteData.estimatedGas?.toString() || "300000",
    protocols: [
      {
        name: "OpenOcean",
        part: 100,
        fromTokenAddress: src,
        toTokenAddress: dst,
      },
    ],
    tx: quoteData.data
      ? {
          to: quoteData.to,
          data: quoteData.data,
          value: quoteData.value || "0",
          gasLimit: quoteData.estimatedGas?.toString() || "300000",
        }
      : undefined,
    isRealQuote: true,
    priceSource: "OpenOcean",
    timestamp: new Date().toISOString(),
  }
}

// ParaSwap API Implementation
async function tryParaSwapQuote(src: string, dst: string, amount: string, account?: string) {
  const priceUrl = `https://apiv5.paraswap.io/prices?srcToken=${src}&destToken=${dst}&amount=${amount}&srcDecimals=4&destDecimals=18&side=SELL&network=137`

  console.log("📞 ParaSwap Price URL:", priceUrl)

  const response = await fetch(priceUrl, {
    headers: {
      accept: "application/json",
    },
    timeout: 10000,
  })

  const responseText = await response.text()
  console.log("📋 ParaSwap Response:", {
    status: response.status,
    bodyLength: responseText.length,
    bodyPreview: responseText.substring(0, 300),
  })

  if (!response.ok) {
    throw new Error(`ParaSwap API error: ${response.status} - ${responseText}`)
  }

  const priceData = JSON.parse(responseText)

  if (!priceData.priceRoute || !priceData.priceRoute.destAmount) {
    throw new Error("ParaSwap: Invalid price response")
  }

  // Get transaction data if account provided
  let txData = null
  if (account && account.startsWith("0x")) {
    try {
      const txUrl = "https://apiv5.paraswap.io/transactions/137"
      const txResponse = await fetch(txUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          srcToken: src,
          destToken: dst,
          srcAmount: amount,
          destAmount: priceData.priceRoute.destAmount,
          priceRoute: priceData.priceRoute,
          userAddress: account,
          slippage: 100, // 1%
        }),
        timeout: 10000,
      })

      if (txResponse.ok) {
        const txResponseData = await txResponse.json()
        txData = {
          to: txResponseData.to,
          data: txResponseData.data,
          value: txResponseData.value || "0",
          gasLimit: "300000",
        }
      }
    } catch (txError) {
      console.log("⚠️ ParaSwap transaction data failed, quote only:", txError.message)
    }
  }

  return {
    srcToken: {
      symbol: "DFAITH",
      address: src,
      decimals: 4,
    },
    dstToken: {
      symbol: "WMATIC",
      address: dst,
      decimals: 18,
    },
    dstAmount: priceData.priceRoute.destAmount,
    estimatedGas: priceData.priceRoute.gasCost || "300000",
    protocols: [
      {
        name: "ParaSwap",
        part: 100,
        fromTokenAddress: src,
        toTokenAddress: dst,
      },
    ],
    tx: txData,
    isRealQuote: true,
    priceSource: "ParaSwap",
    timestamp: new Date().toISOString(),
  }
}

// Intelligent Fallback with realistic pricing
function createFallbackQuote(src: string, dst: string, amount: string, account?: string) {
  console.log("🔄 Creating intelligent fallback quote...")

  // Realistic D.Faith to MATIC rate (based on typical small-cap token rates)
  const dfaithAmount = Number(amount) / Math.pow(10, 18) // Convert from wei to DFAITH
  const estimatedMaticRate = 0.0001 // 1 D.Faith ≈ 0.0001 MATIC (realistic for small tokens)
  const maticAmount = dfaithAmount * estimatedMaticRate
  const maticAmountWei = Math.floor(maticAmount * Math.pow(10, 18)).toString()

  return {
    srcToken: {
      symbol: "DFAITH",
      address: src,
      decimals: 18,
    },
    dstToken: {
      symbol: "WMATIC",
      address: dst,
      decimals: 18,
    },
    dstAmount: maticAmountWei,
    estimatedGas: "250000",
    protocols: [
      {
        name: "Fallback-Estimator",
        part: 100,
        fromTokenAddress: src,
        toTokenAddress: dst,
      },
    ],
    tx: account
      ? {
          to: "0x6352a56caadC4F1E25CD6c75970Fa768A3304e64", // Generic DEX router
          data: "0x", // Placeholder
          value: "0",
          gasLimit: "250000",
        }
      : undefined,
    isRealQuote: false,
    isFallback: true,
    priceSource: "Fallback-Estimator",
    timestamp: new Date().toISOString(),
    warning: "Dies ist eine geschätzte Quote. Echte DEX APIs sind momentan nicht verfügbar.",
  }
}
